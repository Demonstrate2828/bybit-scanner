package com.scanner.bybit

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.atomic.AtomicBoolean

// Один цикл работы: скан рынка, проверка демо-сделок, уведомления. Его вызывают и служба, и резервная задача.
object Engine {
    private val busy = AtomicBoolean(false)
    private val seenN = HashSet<String>()

    fun channels(c: Context) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("status", "Работа сканера", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("signals", "Сигналы входа", NotificationManager.IMPORTANCE_HIGH).apply { enableVibration(true) })
        nm.createNotificationChannel(NotificationChannel("demo", "Демо-торговля", NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun statusNotif(c: Context): Notification {
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(c, "status").setSmallIcon(android.R.drawable.ic_menu_search).setContentIntent(open)
            .setOngoing(true).setOnlyAlertOnce(true).setContentTitle("Сканер Bybit работает").setContentText(Scanner.info).build()
    }

    fun push(c: Context, ch: String, id: Int, title: String, text: String, url: String?) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val intent = if (url != null) Intent(Intent.ACTION_VIEW, Uri.parse(url)) else Intent(c, MainActivity::class.java)
        val pi = PendingIntent.getActivity(c, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        nm.notify(id, Notification.Builder(c, ch).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title)
            .setContentText(text).setStyle(Notification.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(pi).build())
    }

    // Возвращает, сколько секунд ждать до следующего цикла
    fun cycle(c: Context): Int {
        if (!busy.compareAndSet(false, true)) return 30
        var wait = 120
        try {
            Scanner.info = "Сканирую рынок…"; Store.ver++
            val r = Scanner.scan(Store.cfg(), Store.minVolM)
            Scanner.last = r; Scanner.online = true
            Demo.manage { t -> push(c, "demo", t.sym.hashCode() + 7, (if (t.pnl >= 0) "✅ " else "❌ ") + "Демо: ${t.sym} ${t.reason}",
                (if (t.pnl >= 0) "+" else "") + "%.2f".format(t.pnl) + " $", null) }
            Demo.openNew(r) { p -> push(c, "demo", p.sym.hashCode() + 3, "Демо: открыта ${if (p.long) "ЛОНГ" else "ШОРТ"} ${p.sym}",
                "Вход ${p.entry} · стоп ${"%.5g".format(p.sl)} · тейк ${"%.5g".format(p.tp)}", null) }
            if (Store.liveOn && Live.configured()) {
                try {
                    Live.manage { t, m -> push(c, "signals", t.hashCode(), t, m, null) }
                    Live.open(r) { t, m -> push(c, "signals", t.hashCode(), t, m, null) }
                    Live.err = ""
                } catch (e: Throwable) { Live.err = e.message?.take(150) ?: "ошибка" }
            }
            r.filter { it.st != "watch" }.forEach {
                if (seenN.add("${it.sym}|${it.st}|${it.closeAt}")) {
                    val what = if (it.st == "signal") "Вход сейчас" else "Скоро вход (~${Math.ceil(it.mins).toInt()} мин)"
                    push(c, "signals", (it.sym + it.st).hashCode(), (if (it.long) "🟢 ЛОНГ " else "🔴 ШОРТ ") + "${it.sym} — $what",
                        it.note + " Объём ×" + "%.1f".format(it.vr), "https://www.bybit.com/trade/usdt/${it.sym}")
                }
            }
            Scanner.lastOk = System.currentTimeMillis()
            Scanner.info = "Обновлено " + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        } catch (e: Throwable) {
            Scanner.online = false
            Scanner.info = "Нет связи с Bybit (${e.message?.take(70)}). Демо на паузе, пробую снова…"; wait = 15
        } finally { busy.set(false) }
        Store.ver++
        if (ScanService.alive) try { (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(1, statusNotif(c)) } catch (e: Exception) { }
        return wait
    }
}
