package com.scanner.bybit

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread

class ScanService : Service() {
    @Volatile private var running = false
    private val seen = HashSet<String>()
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_STICKY
        running = true
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("status", "Работа сканера", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("signals", "Сигналы входа", NotificationManager.IMPORTANCE_HIGH).apply { enableVibration(true) })
        val n = Notification.Builder(this, "status").setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("Сканер Bybit работает").setContentText("Проверка рынка каждые 2 минуты").build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bybit:scan").also { it.acquire() }
        thread {
            while (running) {
                try {
                    Scanner.info = "Сканирую…"
                    val r = Scanner.scan()
                    Scanner.last = r
                    Scanner.info = "Обновлено " + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                    r.filter { it.st != "watch" }.forEach { if (seen.add("${it.sym}|${it.st}|${it.closeAt}")) notify(nm, it) }
                } catch (e: Exception) { Scanner.info = "Ошибка: ${e.message}" }
                repeat(120) { if (running) Thread.sleep(1000) }
            }
        }
        return START_STICKY
    }

    private fun notify(nm: NotificationManager, s: Sig) {
        val dir = if (s.long) "🟢 ЛОНГ" else "🔴 ШОРТ"
        val what = if (s.st == "signal") "Вход сейчас" else "Скоро вход (~${Math.ceil(s.mins).toInt()} мин)"
        val pi = PendingIntent.getActivity(this, s.sym.hashCode(),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bybit.com/trade/usdt/${s.sym}")),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        nm.notify((s.sym + s.st).hashCode(), Notification.Builder(this, "signals")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("$dir ${s.sym} — $what")
            .setContentText(s.note).setStyle(Notification.BigTextStyle().bigText(s.note + "\nЦена ${s.price}, EMA 50 ${s.e5}"))
            .setAutoCancel(true).setContentIntent(pi).build())
    }

    override fun onDestroy() { running = false; wl?.release(); super.onDestroy() }
}
