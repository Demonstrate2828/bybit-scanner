package com.scanner.bybit

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import kotlin.concurrent.thread

// Страховка №1: будильник каждые 3 мин поднимает службу, если систему её убила.
// Страховка №2: периодическая задача (раз в ~15 мин) сама делает цикл, даже если службы нет.
object Watchdog {
    fun schedule(c: Context, delayMs: Long = 180_000) {
        try {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(c, 77, Intent(c, WatchdogReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val at = System.currentTimeMillis() + delayMs
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: Exception) { }
    }
    fun job(c: Context) {
        try {
            val js = c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            if (js.getPendingJob(1) == null) js.schedule(JobInfo.Builder(1, ComponentName(c, ScanJob::class.java))
                .setPeriodic(15 * 60_000L).setPersisted(true).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).build())
        } catch (e: Exception) { }
    }
    fun cancelAll(c: Context) {
        try {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(PendingIntent.getBroadcast(c, 77, Intent(c, WatchdogReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            (c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler).cancel(1)
        } catch (e: Exception) { }
    }
}

class WatchdogReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.init(c)
        if (!Store.enabled) return
        Watchdog.schedule(c)
        if (!ScanService.alive) try { c.startForegroundService(Intent(c, ScanService::class.java)) } catch (e: Exception) { }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.init(c)
        if (!Store.enabled) return
        try { c.startForegroundService(Intent(c, ScanService::class.java)) } catch (e: Exception) { }
        Watchdog.schedule(c, 60_000); Watchdog.job(c)
    }
}

class ScanJob : JobService() {
    override fun onStartJob(p: JobParameters): Boolean {
        Store.init(this)
        if (!Store.enabled || ScanService.alive) return false
        thread { try { Engine.cycle(this) } catch (e: Throwable) { }; jobFinished(p, false) }
        return true
    }
    override fun onStopJob(p: JobParameters) = true
}

class ScanService : Service() {
    companion object { @Volatile var alive = false }
    @Volatile private var running = false
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_STICKY
        Store.init(this); running = true; alive = true
        Engine.channels(this)
        val n = Engine.statusNotif(this)
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        } catch (e: Exception) { Scanner.info = "Не удалось запустить службу: ${e.message}"; running = false; alive = false; stopSelf(); return START_NOT_STICKY }
        wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bybit:scan").also { it.acquire() }
        Watchdog.schedule(this); Watchdog.job(this)
        thread {
            while (running) {
                val wait = Engine.cycle(this)
                Watchdog.schedule(this)
                var k = 0; while (running && k < wait && !Scanner.kick) { Thread.sleep(1000); k++ }; Scanner.kick = false
            }
        }
        return START_STICKY
    }

    // Если приложение смахнули из недавних, через 5 секунд будильник поднимет службу заново
    override fun onTaskRemoved(rootIntent: Intent?) { if (Store.enabled) Watchdog.schedule(this, 5_000); super.onTaskRemoved(rootIntent) }
    override fun onDestroy() { running = false; alive = false; wl?.release(); super.onDestroy() }
}
