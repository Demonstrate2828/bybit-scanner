package com.scanner.bybit

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.init(c)
        if (Store.enabled) c.startForegroundService(Intent(c, ScanService::class.java))
    }
}

class ScanService : Service() {
    @Volatile private var running = false
    private var wl: PowerManager.WakeLock? = null
    private val seenN = HashSet<String>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_STICKY
        Store.init(this); running = true
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("status", "Работа сканера", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("signals", "Сигналы входа", NotificationManager.IMPORTANCE_HIGH).apply { enableVibration(true) })
        nm.createNotificationChannel(NotificationChannel("demo", "Демо-торговля", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "status").setSmallIcon(android.R.drawable.ic_menu_search).setContentIntent(open)
            .setContentTitle("Сканер Bybit работает").setContentText("Рынок и демо-счёт обновляются каждые 2 минуты").build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bybit:scan").also { it.acquire() }
        thread {
            while (running) {
                var wait = 120
                try {
                    Scanner.info = "Сканирую рынок…"; Store.ver++
                    val r = Scanner.scan(Store.win, Store.near, Store.minVolM, Store.minVr)
                    Scanner.last = r; Scanner.online = true
                    Demo.manage { t -> push(nm, "demo", t.sym.hashCode() + 7, (if (t.pnl >= 0) "✅ " else "❌ ") + "Демо: ${t.sym} ${t.reason}",
                        (if (t.pnl >= 0) "+" else "") + "%.2f".format(t.pnl) + " $", null) }
                    Demo.openNew(r) { p -> push(nm, "demo", p.sym.hashCode() + 3, "Демо: открыта ${if (p.long) "ЛОНГ" else "ШОРТ"} ${p.sym}",
                        "Вход ${p.entry} · стоп ${"%.5g".format(p.sl)} · тейк ${"%.5g".format(p.tp)}", null) }
                    r.filter { it.st != "watch" }.forEach {
                        if (seenN.add("${it.sym}|${it.st}|${it.closeAt}")) {
                            val what = if (it.st == "signal") "Вход сейчас" else "Скоро вход (~${Math.ceil(it.mins).toInt()} мин)"
                            push(nm, "signals", (it.sym + it.st).hashCode(), (if (it.long) "🟢 ЛОНГ " else "🔴 ШОРТ ") + "${it.sym} — $what",
                                it.note + " Объём ×" + "%.1f".format(it.vr), "https://www.bybit.com/trade/usdt/${it.sym}")
                        }
                    }
                    Scanner.info = "Обновлено " + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                } catch (e: Exception) {
                    Scanner.online = false
                    Scanner.info = "Нет связи с Bybit. Демо на паузе, пробую снова…"; wait = 15
                }
                Store.ver++
                var k = 0; while (running && k < wait) { Thread.sleep(1000); k++ }
            }
        }
        return START_STICKY
    }

    private fun push(nm: NotificationManager, ch: String, id: Int, title: String, text: String, url: String?) {
        val intent = if (url != null) Intent(Intent.ACTION_VIEW, Uri.parse(url)) else Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(this, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        nm.notify(id, Notification.Builder(this, ch).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title)
            .setContentText(text).setStyle(Notification.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(pi).build())
    }

    override fun onDestroy() { running = false; wl?.release(); super.onDestroy() }
}
