package com.scanner.bybit

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.math.BigDecimal
import java.math.RoundingMode
import java.net.HttpURLConnection
import java.net.URL
import java.security.Key
import java.security.KeyStore
import java.text.SimpleDateFormat
import java.util.*
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlin.math.abs

// Ключи хранятся зашифрованными (AES-GCM, ключ лежит в Android Keystore и не покидает телефон)
object Crypto {
    private const val ALIAS = "bybit_scanner_key"
    private fun key(): Key {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        ks.getKey(ALIAS, null)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return g.generateKey()
    }
    fun enc(s: String): String {
        if (s.isEmpty()) return ""
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, key())
        return Base64.encodeToString(c.iv + c.doFinal(s.toByteArray()), Base64.NO_WRAP)
    }
    fun dec(s: String): String {
        if (s.isEmpty()) return ""
        return try {
            val b = Base64.decode(s, Base64.NO_WRAP); val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, b.copyOfRange(0, 12)))
            String(c.doFinal(b.copyOfRange(12, b.size)))
        } catch (e: Exception) { "" }
    }
}

// Реальная торговля через Bybit API v5 (линейные USDT-перпетуалы, one-way режим позиции)
object Live {
    @Volatile var status = "Не подключено"
    @Volatile var verified = false
    @Volatile var equity = 0.0
    @Volatile var err = ""
    @Volatile var positions: List<String> = emptyList()
    private val inst = HashMap<String, DoubleArray>()
    @Volatile private var offset = 0L
    @Volatile private var offsetAt = 0L

    private fun base() = if (Store.testnet) "https://api-testnet.bybit.com" else "https://api.bybit.com"
    fun configured() = Store.apiKey().isNotEmpty() && Store.apiSecret().isNotEmpty()

    private fun hmac(secret: String, s: String): String {
        val m = Mac.getInstance("HmacSHA256"); m.init(SecretKeySpec(secret.toByteArray(), "HmacSHA256"))
        return m.doFinal(s.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    private fun call(post: Boolean, path: String, params: String, auth: Boolean = true): JSONObject {
        if (auth && System.currentTimeMillis() - offsetAt > 600_000) {   // сверяем часы с биржей
            try {
                val t = ok(call(false, "/v5/market/time", "", false)).getString("timeSecond").toLong() * 1000
                offset = t - System.currentTimeMillis(); offsetAt = System.currentTimeMillis()
            } catch (e: Exception) { }
        }
        val ts = (System.currentTimeMillis() + offset).toString(); val rw = "10000"
        val key = Store.apiKey(); val sec = Store.apiSecret()
        val c = URL(base() + path + (if (!post && params.isNotEmpty()) "?$params" else "")).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 15000; c.requestMethod = if (post) "POST" else "GET"
        if (auth) {
            c.setRequestProperty("X-BAPI-API-KEY", key); c.setRequestProperty("X-BAPI-TIMESTAMP", ts)
            c.setRequestProperty("X-BAPI-RECV-WINDOW", rw); c.setRequestProperty("X-BAPI-SIGN", hmac(sec, ts + key + rw + params))
        }
        if (post) { c.doOutput = true; c.setRequestProperty("Content-Type", "application/json"); c.outputStream.use { it.write(params.toByteArray()) } }
        val code = c.responseCode
        val txt = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: "{}"
        return try { JSONObject(txt) } catch (e: Exception) { throw Exception("HTTP $code") }
    }
    private fun ok(j: JSONObject): JSONObject {
        if (j.optInt("retCode", -1) != 0) throw Exception("${j.optInt("retCode")}: ${j.optString("retMsg")}")
        return j.optJSONObject("result") ?: JSONObject()
    }
    private fun get(path: String, q: String) = ok(call(false, path, q))
    private fun post(path: String, body: JSONObject) = call(true, path, body.toString())

    private fun fmt(x: Double, step: Double, down: Boolean): String {
        val dec = BigDecimal.valueOf(step).stripTrailingZeros().scale().coerceAtLeast(0)
        val q = BigDecimal(x / step).setScale(0, if (down) RoundingMode.DOWN else RoundingMode.HALF_UP)
        return q.multiply(BigDecimal.valueOf(step)).setScale(dec, RoundingMode.HALF_UP).toPlainString()
    }
    // qtyStep, minOrderQty, tickSize, minNotional, maxMktOrderQty
    private fun info(sym: String): DoubleArray = inst.getOrPut(sym) {
        val r = ok(call(false, "/v5/market/instruments-info", "category=linear&symbol=$sym", false)).getJSONArray("list").getJSONObject(0)
        val lf = r.getJSONObject("lotSizeFilter"); val pf = r.getJSONObject("priceFilter")
        doubleArrayOf(lf.getString("qtyStep").toDouble(), lf.getString("minOrderQty").toDouble(), pf.getString("tickSize").toDouble(),
            lf.optString("minNotionalValue", "5").toDoubleOrNull() ?: 5.0, lf.optString("maxMktOrderQty", "").toDoubleOrNull() ?: 1e18)
    }
    private fun lastPrice(sym: String): Double =
        ok(call(false, "/v5/market/tickers", "category=linear&symbol=$sym", false)).getJSONArray("list").getJSONObject(0).getString("lastPrice").toDouble()

    fun fetchEquity(): Double {
        var last: Exception? = null
        for (t in listOf("UNIFIED", "CONTRACT")) {
            try {
                val l = get("/v5/account/wallet-balance", "accountType=$t").getJSONArray("list")
                if (l.length() > 0) {
                    val o = l.getJSONObject(0)
                    o.optString("totalEquity", "").toDoubleOrNull()?.let { return it }
                    val cs = o.optJSONArray("coin")
                    if (cs != null) for (i in 0 until cs.length()) { val c = cs.getJSONObject(i)
                        if (c.optString("coin") == "USDT") return c.optString("equity", c.optString("walletBalance", "0")).toDouble() }
                }
            } catch (e: Exception) { last = e }
        }
        throw last ?: Exception("не удалось получить баланс")
    }

    fun check() {
        verified = false; err = ""
        val q = get("/v5/user/query-api", "")
        if ((q.optJSONObject("permissions")?.toString() ?: "").contains("Withdraw")) { status = "⚠ У ключа есть право вывода средств. Создай новый ключ БЕЗ вывода."; return }
        if (q.optInt("readOnly", 0) == 1) { status = "⚠ Ключ только для чтения. Включи торговлю контрактами."; return }
        equity = fetchEquity(); verified = true
        status = "Подключено: " + (if (Store.testnet) "Testnet" else "реальный счёт")
    }

    private fun logL(s: String) = synchronized(Store) {
        Store.llog.add(0, SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date()) + "  " + s)
        while (Store.llog.size > 40) Store.llog.removeAt(Store.llog.size - 1); Store.ver++; Store.save()
    }
    private fun dayKey() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
    private fun addDay(p: Double) = synchronized(Store) {
        if (Store.lDayKey != dayKey()) { Store.lDayKey = dayKey(); Store.lDayPnl = 0.0 }
        Store.lDayPnl += p
    }
    private fun dayHit(eq: Double): Boolean = synchronized(Store) {
        if (Store.lDayKey != dayKey()) { Store.lDayKey = dayKey(); Store.lDayPnl = 0.0 }
        Store.lDayPnl <= -eq * Store.lDay / 100
    }

    fun open(sigs: List<Sig>, say: (String, String) -> Unit) {
        if (!Store.liveOn || !configured()) return
        val eq = fetchEquity(); equity = eq
        if (eq < 10 || dayHit(eq)) return
        for (s in sigs) {
            if (s.st != "signal") continue
            val key = s.sym + "|" + s.closeAt
            val go = synchronized(Store) {
                if (Store.lseen.contains(key) || Store.lpos.any { it.sym == s.sym } || Store.lpos.size >= Store.lMaxPos) false
                else { Store.lseen.add(key); while (Store.lseen.size > 150) Store.lseen.removeAt(0); true }
            }
            if (!go) continue
            try { place(s, eq, say) } catch (e: Exception) { logL("${s.sym}: не открыто, ${e.message?.take(110)}") }
        }
    }

    private fun place(s: Sig, eq: Double, say: (String, String) -> Unit) {
        val px = lastPrice(s.sym)                                  // цена на той бирже, где торгуем (на Testnet цены другие)
        val dPct = abs(s.price - s.ext) / s.price + 0.001          // стоп как доля цены
        if (dPct * 100 < Store.minStop || dPct * 100 > Store.maxStop) { logL("${s.sym}: пропуск, стоп вне лимитов"); return }
        val d = px * dPct; val inf = info(s.sym)
        val qs = fmt(minOf(eq * Store.lRisk / 100 / d, eq * Store.lLev * 0.9 / px, inf[4]), inf[0], true)
        val qty = qs.toDouble()
        if (qty < inf[1] || qty * px < inf[3]) { logL("${s.sym}: пропуск, слишком малый размер для риска ${Store.lRisk}%"); return }
        post("/v5/position/set-leverage", JSONObject().put("category", "linear").put("symbol", s.sym)
            .put("buyLeverage", Store.lLev.toString()).put("sellLeverage", Store.lLev.toString()))   // ошибку «не изменено» игнорируем
        val L = s.long
        val sl = if (L) px - d else px + d; val tp = if (L) px + d * Store.rr else px - d * Store.rr
        val body = JSONObject().put("category", "linear").put("symbol", s.sym).put("side", if (L) "Buy" else "Sell").put("orderType", "Market")
            .put("qty", qs).put("positionIdx", 0).put("stopLoss", fmt(sl, inf[2], false)).put("takeProfit", fmt(tp, inf[2], false))
            .put("tpslMode", "Full").put("slTriggerBy", "LastPrice").put("tpTriggerBy", "LastPrice")
            .put("orderLinkId", ("bs" + s.sym + (s.closeAt / 60000)).take(36))
        ok(post("/v5/order/create", body))
        synchronized(Store) { Store.lpos.add(LP(s.sym, L, px, d, qty, 0, System.currentTimeMillis())); Store.ver++; Store.save() }
        val t = (if (L) "🟢 РЕАЛ ЛОНГ " else "🔴 РЕАЛ ШОРТ ") + s.sym
        val m = "Объём $qs, стоп ${fmt(sl, inf[2], false)}, тейк ${fmt(tp, inf[2], false)}"
        logL("$t. $m"); say(t, m)
    }

    // Сопровождение: +1R частичная фиксация и стоп в безубыток, +2R стоп на +1R (стоп и тейк стоят на бирже)
    fun manage(say: (String, String) -> Unit) {
        if (!configured()) return
        val snap = synchronized(Store) { Store.lpos.toList() }
        val pl = get("/v5/position/list", "category=linear&settleCoin=USDT").getJSONArray("list")
        val live = HashMap<String, JSONObject>()
        for (i in 0 until pl.length()) { val o = pl.getJSONObject(i); if ((o.optString("size", "0").toDoubleOrNull() ?: 0.0) > 0.0) live[o.getString("symbol")] = o }
        positions = live.values.map { "${it.getString("symbol")} ${if (it.getString("side") == "Buy") "ЛОНГ" else "ШОРТ"} · ${it.getString("size")} · PnL ${it.optString("unrealisedPnl")}" }
        for (p in snap) {
            val o = live[p.sym]
            if (o == null) {
                if (System.currentTimeMillis() - p.openedAt < 20_000) continue
                val pnl = try { get("/v5/position/closed-pnl", "category=linear&symbol=${p.sym}&limit=1").getJSONArray("list").getJSONObject(0).getString("closedPnl").toDouble() } catch (e: Exception) { 0.0 }
                synchronized(Store) { Store.lpos.remove(p); Store.ver++; Store.save() }
                addDay(pnl)
                val t = (if (pnl >= 0) "✅ РЕАЛ " else "❌ РЕАЛ ") + p.sym + " закрыта"
                val m = (if (pnl >= 0) "+" else "") + "%.2f".format(pnl) + " USDT"
                logL("$t: $m"); say(t, m); continue
            }
            val mark = o.optString("markPrice", "").toDoubleOrNull() ?: continue
            if (p.stage == 0) o.optString("avgPrice", "").toDoubleOrNull()?.let { p.entry = it }
            val L = p.long; val inf = info(p.sym)
            fun reached(k: Double) = if (L) mark >= p.entry + p.d * k else mark <= p.entry - p.d * k
            fun moveSl(px: Double) = ok(post("/v5/position/trading-stop", JSONObject().put("category", "linear").put("symbol", p.sym)
                .put("stopLoss", fmt(px, inf[2], false)).put("slTriggerBy", "LastPrice").put("tpslMode", "Full").put("positionIdx", 0)))
            try {
                if (p.stage == 0 && reached(1.0)) {
                    val size = o.getString("size").toDouble()
                    val cq = fmt(size * Store.partial / 100, inf[0], true).toDouble()
                    if (Store.partial > 0 && cq >= inf[1] && size - cq >= inf[1])
                        ok(post("/v5/order/create", JSONObject().put("category", "linear").put("symbol", p.sym).put("side", if (L) "Sell" else "Buy")
                            .put("orderType", "Market").put("qty", fmt(cq, inf[0], true)).put("reduceOnly", true).put("positionIdx", 0)))
                    if (Store.beOn) moveSl(if (L) p.entry * 1.0012 else p.entry * 0.9988)    // безубыток с запасом на комиссии
                    p.stage = 1; logL("${p.sym}: +1R, часть закрыта, стоп в безубыток"); synchronized(Store) { Store.save() }
                } else if (p.stage == 1 && reached(2.0)) {
                    moveSl(if (L) p.entry + p.d else p.entry - p.d)
                    p.stage = 2; logL("${p.sym}: +2R, стоп на +1R"); synchronized(Store) { Store.save() }
                }
            } catch (e: Exception) { logL("${p.sym}: сопровождение не удалось, ${e.message?.take(90)}") }
        }
    }

    // Аварийная кнопка: отменить ордера, закрыть все позиции по рынку, выключить автоторговлю
    fun panic() {
        Store.liveOn = false; Store.save()
        if (!configured()) return
        try { post("/v5/order/cancel-all", JSONObject().put("category", "linear").put("settleCoin", "USDT")) } catch (e: Exception) { }
        val pl = get("/v5/position/list", "category=linear&settleCoin=USDT").getJSONArray("list")
        var n = 0
        for (i in 0 until pl.length()) {
            val o = pl.getJSONObject(i); val sz = o.optString("size", "0")
            if ((sz.toDoubleOrNull() ?: 0.0) <= 0.0) continue
            ok(post("/v5/order/create", JSONObject().put("category", "linear").put("symbol", o.getString("symbol"))
                .put("side", if (o.getString("side") == "Buy") "Sell" else "Buy").put("orderType", "Market").put("qty", sz)
                .put("reduceOnly", true).put("positionIdx", 0))); n++
        }
        synchronized(Store) { Store.lpos.clear(); Store.save() }
        logL("Аварийная остановка: закрыто позиций $n, автоторговля выключена")
        status = "Остановлено, позиций закрыто: $n"
    }
}
