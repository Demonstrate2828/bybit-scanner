package com.scanner.bybit

import java.util.Calendar

object Demo {
    private const val FEE = 0.00055   // комиссия тейкера Bybit с каждой стороны

    fun pnl(long: Boolean, entry: Double, exit: Double, qty: Double) =
        (if (long) exit - entry else entry - exit) * qty - FEE * (entry + exit) * qty
    fun upnl(p: Pos) = p.realized + pnl(p.long, p.entry, p.last, p.qty * p.rem)
    fun equity(): Double = synchronized(Store) { Store.balance + Store.open.sumOf { upnl(it) } }

    fun reset() = synchronized(Store) {
        Store.balance = Store.deposit; Store.open.clear(); Store.closed.clear(); Store.ver++; Store.save()
    }

    fun dayLimitHit(): Boolean = synchronized(Store) {
        val s = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        val pn = Store.closed.filter { it.closedAt >= s }.sumOf { it.pnl }
        Store.dayLoss > 0 && pn <= -Store.balance * Store.dayLoss / 100
    }

    // Один шаг управления сделкой по свече (общий для демо и бэктеста).
    // Стоп проверяется первым (осторожно). На +1R: частичная фиксация и/или стоп в безубыток.
    fun step(p: Pos, hi: Double, lo: Double, t: Long, cf: Cfg): Pair<Double, String>? {
        val L = p.long
        if (if (L) lo <= p.sl else hi >= p.sl) return Pair(p.sl, if (p.stage == 0) "SL" else if (p.sl == p.entry) "BE" else "SL")
        if (p.stage == 0 && (cf.partial > 0 || cf.beOn)) {
            val one = if (L) p.entry + p.r0 else p.entry - p.r0
            if (if (L) hi >= one else lo <= one) {
                if (cf.partial > 0) { p.realized += pnl(L, p.entry, one, p.qty * cf.partial); p.rem = 1 - cf.partial }
                if (cf.beOn) p.sl = p.entry
                p.stage = 1; p.stageAt = t
            }
        }
        if (if (L) hi >= p.tp else lo <= p.tp) return Pair(p.tp, "TP")
        return null
    }

    // Проверка открытых сделок по истории 5м-свечей с момента последней проверки:
    // после потери связи всё пересчитывается задним числом.
    fun manage(onClose: (Trade) -> Unit) {
        val snap = synchronized(Store) { Store.open.toList() }
        val now = System.currentTimeMillis(); val cf = Store.cfg()
        for (p in snap) {
            val kl = Scanner.klines(p.sym, p.checkedTo)
            var exit = Double.NaN; var why = ""; var tc = now
            for (k in kl) {
                val e = step(p, k[2], k[3], k[0].toLong(), cf)
                if (e != null) { exit = e.first; why = e.second; tc = k[0].toLong(); break }
            }
            if (exit.isNaN() && kl.isNotEmpty()) {
                if (p.stage == 1 && cf.trail) {   // остаток ведём по EMA 50 на 1Ч
                    val ti = Scanner.trailInfo(p.sym)
                    if (ti.first > p.stageAt && (if (p.long) ti.second < ti.third else ti.second > ti.third)) { exit = kl.last()[4]; why = "EMA" }
                }
                if (exit.isNaN() && now - p.openedAt > 72 * 3_600_000L) { exit = kl.last()[4]; why = "Время" }
            }
            var tr: Trade? = null
            synchronized(Store) {
                if (!exit.isNaN()) {
                    val pn = p.realized + pnl(p.long, p.entry, exit, p.qty * p.rem)
                    Store.balance += pn; Store.open.remove(p)
                    tr = Trade(p.sym, p.long, p.entry, exit, pn, why, p.openedAt, tc, p.vr)
                    Store.closed.add(0, tr!!); while (Store.closed.size > 200) Store.closed.removeAt(Store.closed.size - 1)
                } else if (kl.isNotEmpty()) { p.checkedTo = kl.last()[0].toLong(); p.last = kl.last()[4] }
                Store.ver++; Store.save()
            }
            val t = tr; if (t != null) onClose(t)
        }
    }

    fun openNew(sigs: List<Sig>, onOpen: (Pos) -> Unit) {
        if (dayLimitHit()) return
        for (s in sigs) {
            if (s.st != "signal") continue
            var np: Pos? = null
            synchronized(Store) {
                val key = s.sym + "|" + s.closeAt
                if (Store.seen.contains(key) || Store.open.any { it.sym == s.sym } || Store.open.size >= Store.maxPos || Store.balance <= 1) return@synchronized
                Store.seen.add(key); while (Store.seen.size > 150) Store.seen.removeAt(0)
                val e = s.price
                val d = Math.abs(e - s.ext) + e * 0.001           // стоп за хвостом сигнальной свечи
                val sl = if (s.long) e - d else e + d
                val tp = if (s.long) e + d * Store.rr else e - d * Store.rr
                val q = minOf(Store.balance * Store.riskPct / 100 / d, Store.balance * 2 / e)
                val now = System.currentTimeMillis()
                np = Pos(s.sym, s.long, e, sl, tp, q, now, now, e, d, s.vr)
                Store.open.add(np!!); Store.ver++; Store.save()
            }
            val p = np; if (p != null) onOpen(p)
        }
    }
}
