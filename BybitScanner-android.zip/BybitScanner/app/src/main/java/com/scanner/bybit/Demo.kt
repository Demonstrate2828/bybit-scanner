package com.scanner.bybit

object Demo {
    private const val FEE = 0.00055   // комиссия тейкера Bybit с каждой стороны

    fun pnl(long: Boolean, entry: Double, exit: Double, qty: Double) =
        (if (long) exit - entry else entry - exit) * qty - FEE * (entry + exit) * qty
    fun upnl(p: Pos) = pnl(p.long, p.entry, p.last, p.qty)
    fun equity(): Double = synchronized(Store) { Store.balance + Store.open.sumOf { upnl(it) } }

    fun reset() = synchronized(Store) {
        Store.balance = Store.deposit; Store.open.clear(); Store.closed.clear(); Store.ver++; Store.save()
    }

    // Проверка открытых сделок по истории 5м-свечей с момента последней проверки.
    // После потери связи всё пересчитывается задним числом, ничего не теряется.
    fun manage(onClose: (Trade) -> Unit) {
        val snap = synchronized(Store) { Store.open.toList() }
        val now = System.currentTimeMillis()
        for (p in snap) {
            val kl = Scanner.klines(p.sym, p.checkedTo)
            var exit = Double.NaN; var why = ""; var tc = now
            for (k in kl) {
                val slHit = if (p.long) k[3] <= p.sl else k[2] >= p.sl
                val tpHit = if (p.long) k[2] >= p.tp else k[3] <= p.tp
                if (slHit) { exit = p.sl; why = "SL"; tc = k[0].toLong(); break }   // если в одной свече оба: считаем стоп (осторожно)
                if (tpHit) { exit = p.tp; why = "TP"; tc = k[0].toLong(); break }
            }
            if (kl.isNotEmpty() && exit.isNaN() && now - p.openedAt > 72 * 3_600_000L) { exit = kl.last()[4]; why = "Время" }
            var tr: Trade? = null
            synchronized(Store) {
                if (!exit.isNaN()) {
                    val pn = pnl(p.long, p.entry, exit, p.qty)
                    Store.balance += pn; Store.open.remove(p)
                    tr = Trade(p.sym, p.long, p.entry, exit, pn, why, p.openedAt, tc)
                    Store.closed.add(0, tr!!); while (Store.closed.size > 200) Store.closed.removeAt(Store.closed.size - 1)
                } else if (kl.isNotEmpty()) { p.checkedTo = kl.last()[0].toLong(); p.last = kl.last()[4] }
                Store.ver++; Store.save()
            }
            val t = tr; if (t != null) onClose(t)
        }
    }

    fun openNew(sigs: List<Sig>, onOpen: (Pos) -> Unit) {
        for (s in sigs) {
            if (s.st != "signal") continue
            var np: Pos? = null
            synchronized(Store) {
                val key = s.sym + "|" + s.closeAt
                if (Store.seen.contains(key) || Store.open.any { it.sym == s.sym } || Store.open.size >= 5 || Store.balance <= 1) return@synchronized
                Store.seen.add(key); while (Store.seen.size > 150) Store.seen.removeAt(0)
                val e = s.price
                var d = Math.abs(e - s.ext) + e * 0.001           // стоп за хвостом сигнальной свечи
                if (d < e * 0.003) d = e * 0.003
                val sl = if (s.long) e - d else e + d
                val tp = if (s.long) e + d * Store.rr else e - d * Store.rr
                val q = minOf(Store.balance * Store.riskPct / 100 / d, Store.balance * 2 / e)
                val now = System.currentTimeMillis()
                np = Pos(s.sym, s.long, e, sl, tp, q, now, now, e)
                Store.open.add(np!!); Store.ver++; Store.save()
            }
            val p = np; if (p != null) onOpen(p)
        }
    }
}
