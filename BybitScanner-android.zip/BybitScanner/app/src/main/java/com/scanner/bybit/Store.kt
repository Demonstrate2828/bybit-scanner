package com.scanner.bybit

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class Pos(val sym: String, val long: Boolean, val entry: Double, val sl: Double, val tp: Double,
               val qty: Double, val openedAt: Long, var checkedTo: Long, var last: Double)
data class Trade(val sym: String, val long: Boolean, val entry: Double, val exit: Double, val pnl: Double,
                 val reason: String, val openedAt: Long, val closedAt: Long)

object Store {
    private var sp: SharedPreferences? = null
    var win = 20; var near = 1.0; var minVolM = 1.0; var minVr = 0.0
    var riskPct = 1.0; var rr = 2.0; var deposit = 1000.0
    var enabled = false; var balance = 1000.0
    val open = ArrayList<Pos>(); val closed = ArrayList<Trade>(); val seen = ArrayList<String>()
    @Volatile var ver = 0

    @Synchronized fun init(c: Context) {
        if (sp != null) return
        sp = c.applicationContext.getSharedPreferences("bybit", 0); load()
    }

    private fun load() {
        try {
            val j = JSONObject(sp!!.getString("st", "{}")!!)
            win = j.optInt("win", 20); near = j.optDouble("near", 1.0); minVolM = j.optDouble("vol", 1.0)
            minVr = j.optDouble("vr", 0.0); riskPct = j.optDouble("risk", 1.0); rr = j.optDouble("rr", 2.0)
            deposit = j.optDouble("dep", 1000.0); enabled = j.optBoolean("en", false); balance = j.optDouble("bal", deposit)
            j.optJSONArray("open")?.let { a -> for (i in 0 until a.length()) { val o = a.getJSONObject(i)
                open.add(Pos(o.getString("s"), o.getBoolean("l"), o.getDouble("e"), o.getDouble("sl"), o.getDouble("tp"),
                    o.getDouble("q"), o.getLong("t"), o.getLong("c"), o.getDouble("p"))) } }
            j.optJSONArray("closed")?.let { a -> for (i in 0 until a.length()) { val o = a.getJSONObject(i)
                closed.add(Trade(o.getString("s"), o.getBoolean("l"), o.getDouble("e"), o.getDouble("x"), o.getDouble("p"),
                    o.getString("r"), o.getLong("o"), o.getLong("c"))) } }
            j.optJSONArray("seen")?.let { a -> for (i in 0 until a.length()) seen.add(a.getString(i)) }
        } catch (e: Exception) { }
    }

    @Synchronized fun save() {
        val j = JSONObject().put("win", win).put("near", near).put("vol", minVolM).put("vr", minVr).put("risk", riskPct)
            .put("rr", rr).put("dep", deposit).put("en", enabled).put("bal", balance)
        val o = JSONArray(); open.forEach { o.put(JSONObject().put("s", it.sym).put("l", it.long).put("e", it.entry).put("sl", it.sl)
            .put("tp", it.tp).put("q", it.qty).put("t", it.openedAt).put("c", it.checkedTo).put("p", it.last)) }
        val c = JSONArray(); closed.forEach { c.put(JSONObject().put("s", it.sym).put("l", it.long).put("e", it.entry).put("x", it.exit)
            .put("p", it.pnl).put("r", it.reason).put("o", it.openedAt).put("c", it.closedAt)) }
        val s = JSONArray(); seen.forEach { s.put(it) }
        j.put("open", o).put("closed", c).put("seen", s)
        sp?.edit()?.putString("st", j.toString())?.apply()
    }
}
