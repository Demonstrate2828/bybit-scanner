package com.scanner.bybit

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class Pos(val sym: String, val long: Boolean, val entry: Double, var sl: Double, val tp: Double, val qty: Double,
               val openedAt: Long, var checkedTo: Long, var last: Double, val r0: Double, val vr: Double,
               var stage: Int = 0, var stageAt: Long = 0, var rem: Double = 1.0, var realized: Double = 0.0)
data class LP(val sym: String, val long: Boolean, var entry: Double, val d: Double, val qty: Double, var stage: Int, val openedAt: Long)
data class Trade(val sym: String, val long: Boolean, val entry: Double, val exit: Double, val pnl: Double,
                 val reason: String, val openedAt: Long, val closedAt: Long, val vr: Double = 0.0)

// Набор правил: используется и сканером, и демо, и бэктестом
data class Cfg(val win: Int, val near: Double, val minVr: Double, val adxMin: Double, val minStop: Double, val maxStop: Double,
               val btcOn: Boolean, val htfOn: Boolean, val fundOn: Boolean, val rr: Double, val partial: Double,
               val beOn: Boolean, val trail: Boolean, val minBody: Double = 0.0, val dir: Int = 0)

object Store {
    private var sp: SharedPreferences? = null
    var win = 20; var near = 1.0; var minVolM = 1.0; var minVr = 0.0
    var riskPct = 1.0; var rr = 2.0; var deposit = 1000.0
    var adxMin = 20.0; var minStop = 0.4; var maxStop = 4.0; var maxPos = 5; var dayLoss = 3.0; var partial = 50.0
    var beOn = true; var trail = true; var btcOn = true; var htfOn = true; var fundOn = true
    var enabled = false; var balance = 1000.0; var oemDone = false
    val open = ArrayList<Pos>(); val closed = ArrayList<Trade>(); val seen = ArrayList<String>()
    @Volatile var ver = 0

    var minBody = 0.3; var dirMode = 0
    var liveOn = false; var testnet = true; var lRisk = 0.5; var lMaxPos = 3; var lLev = 5; var lDay = 2.0; var lDayPnl = 0.0; var lDayKey = ""
    val lpos = ArrayList<LP>(); val lseen = ArrayList<String>(); val llog = ArrayList<String>()
    private var kc = ""; private var sc = ""
    fun apiKey() = kc
    fun apiSecret() = sc
    @Synchronized fun setKeys(k: String, s: String) { if (k.isNotEmpty()) kc = k; if (s.isNotEmpty()) sc = s; save() }

    fun cfg() = Cfg(win, near, minVr, adxMin, minStop, maxStop, btcOn, htfOn, fundOn, rr, partial / 100, beOn, trail, minBody, dirMode)

    @Synchronized fun init(c: Context) {
        if (sp != null) return
        sp = c.applicationContext.getSharedPreferences("bybit", 0); load()
    }

    private fun load() {
        try {
            val j = JSONObject(sp!!.getString("st", "{}")!!)
            win = j.optInt("win", 20); near = j.optDouble("near", 1.0); minVolM = j.optDouble("vol", 1.0)
            minVr = j.optDouble("vr", 0.0); riskPct = j.optDouble("risk", 1.0); rr = j.optDouble("rr", 2.0)
            deposit = j.optDouble("dep", 1000.0); enabled = j.optBoolean("en", false); balance = j.optDouble("bal", deposit)
            adxMin = j.optDouble("adx", 20.0); minStop = j.optDouble("mins", 0.4); maxStop = j.optDouble("maxs", 4.0)
            maxPos = j.optInt("mp", 5); dayLoss = j.optDouble("dl", 3.0); partial = j.optDouble("pt", 50.0)
            beOn = j.optBoolean("be", true); trail = j.optBoolean("tr", true); btcOn = j.optBoolean("btc", true)
            htfOn = j.optBoolean("htf", true); fundOn = j.optBoolean("fd", true); oemDone = j.optBoolean("oem", false)
            minBody = j.optDouble("mb", 0.3); dirMode = j.optInt("dm", 0)
            liveOn = j.optBoolean("lon", false); testnet = j.optBoolean("tn", true); lRisk = j.optDouble("lr", 0.5)
            lMaxPos = j.optInt("lmp", 3); lLev = j.optInt("llv", 5); lDay = j.optDouble("ld", 2.0)
            lDayPnl = j.optDouble("ldp", 0.0); lDayKey = j.optString("ldk", "")
            kc = Crypto.dec(j.optString("ke", "")); sc = Crypto.dec(j.optString("se", ""))
            j.optJSONArray("lp")?.let { a -> for (i in 0 until a.length()) { val o = a.getJSONObject(i)
                lpos.add(LP(o.getString("s"), o.getBoolean("l"), o.getDouble("e"), o.getDouble("d"), o.getDouble("q"), o.getInt("g"), o.getLong("t"))) } }
            j.optJSONArray("ls")?.let { a -> for (i in 0 until a.length()) lseen.add(a.getString(i)) }
            j.optJSONArray("lg")?.let { a -> for (i in 0 until a.length()) llog.add(a.getString(i)) }
            j.optJSONArray("open")?.let { a -> for (i in 0 until a.length()) { val o = a.getJSONObject(i)
                val en = o.getDouble("e"); val sl = o.getDouble("sl")
                open.add(Pos(o.getString("s"), o.getBoolean("l"), en, sl, o.getDouble("tp"), o.getDouble("q"), o.getLong("t"),
                    o.getLong("c"), o.getDouble("p"), o.optDouble("r0", Math.abs(en - sl)), o.optDouble("vr", 0.0),
                    o.optInt("sg", 0), o.optLong("sa", 0), o.optDouble("rm", 1.0), o.optDouble("rz", 0.0))) } }
            j.optJSONArray("closed")?.let { a -> for (i in 0 until a.length()) { val o = a.getJSONObject(i)
                closed.add(Trade(o.getString("s"), o.getBoolean("l"), o.getDouble("e"), o.getDouble("x"), o.getDouble("p"),
                    o.getString("r"), o.getLong("o"), o.getLong("c"), o.optDouble("v", 0.0))) } }
            j.optJSONArray("seen")?.let { a -> for (i in 0 until a.length()) seen.add(a.getString(i)) }
        } catch (e: Exception) { }
    }

    @Synchronized fun save() {
        val j = JSONObject().put("win", win).put("near", near).put("vol", minVolM).put("vr", minVr).put("risk", riskPct)
            .put("rr", rr).put("dep", deposit).put("en", enabled).put("bal", balance).put("adx", adxMin).put("mins", minStop)
            .put("maxs", maxStop).put("mp", maxPos).put("dl", dayLoss).put("pt", partial).put("be", beOn).put("tr", trail)
            .put("btc", btcOn).put("htf", htfOn).put("fd", fundOn).put("oem", oemDone)
            .put("mb", minBody).put("dm", dirMode).put("lon", liveOn).put("tn", testnet).put("lr", lRisk).put("lmp", lMaxPos)
            .put("llv", lLev).put("ld", lDay).put("ldp", lDayPnl).put("ldk", lDayKey)
            .put("ke", try { Crypto.enc(kc) } catch (e: Exception) { "" }).put("se", try { Crypto.enc(sc) } catch (e: Exception) { "" })
        val o = JSONArray(); open.forEach { o.put(JSONObject().put("s", it.sym).put("l", it.long).put("e", it.entry).put("sl", it.sl)
            .put("tp", it.tp).put("q", it.qty).put("t", it.openedAt).put("c", it.checkedTo).put("p", it.last).put("r0", it.r0)
            .put("vr", it.vr).put("sg", it.stage).put("sa", it.stageAt).put("rm", it.rem).put("rz", it.realized)) }
        val c = JSONArray(); closed.forEach { c.put(JSONObject().put("s", it.sym).put("l", it.long).put("e", it.entry).put("x", it.exit)
            .put("p", it.pnl).put("r", it.reason).put("o", it.openedAt).put("c", it.closedAt).put("v", it.vr)) }
        val s = JSONArray(); seen.forEach { s.put(it) }
        val lp = JSONArray(); lpos.forEach { lp.put(JSONObject().put("s", it.sym).put("l", it.long).put("e", it.entry).put("d", it.d).put("q", it.qty).put("g", it.stage).put("t", it.openedAt)) }
        val ls = JSONArray(); lseen.forEach { ls.put(it) }; val lg = JSONArray(); llog.forEach { lg.put(it) }
        j.put("open", o).put("closed", c).put("seen", s).put("lp", lp).put("ls", ls).put("lg", lg)
        sp?.edit()?.putString("st", j.toString())?.apply()
    }
}
