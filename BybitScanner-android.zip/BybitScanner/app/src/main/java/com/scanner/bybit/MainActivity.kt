package com.scanner.bybit

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.PowerManager
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

// Фон: медленно плывущие цветные пятна. Поверх них лежат матовые «стеклянные» карточки.
class Aurora(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val cols = intArrayOf(0x66F7A600, 0x5520B26C, 0x553B82F6)
    private val anim = ValueAnimator.ofFloat(0f, 6.2832f).apply {
        duration = 26000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        cv.drawColor(Color.parseColor("#0B0E11"))
        val w = width.toFloat(); val h = height.toFloat()
        for (i in 0..2) {
            val a = t + i * 2.1f
            val cx = w * (0.5f + 0.45f * sin(a)); val cy = h * (0.15f + i * 0.3f + 0.1f * cos(a * 1.3f)); val r = w * 0.85f
            p.shader = RadialGradient(cx, cy, r, cols[i], cols[i] and 0xFFFFFF, Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, r, p)
        }
    }
}

class MainActivity : Activity() {
    private val Y = Color.parseColor("#F7A600"); private val G = Color.parseColor("#20B26C"); private val R = Color.parseColor("#EF454A")
    private val MUT = Color.parseColor("#9AA4B2"); private val TX = Color.parseColor("#F2F4F7"); private val DARK = Color.parseColor("#0B0E11")
    private val OR = Color.parseColor("#FF9F43"); private val BL = Color.parseColor("#5B9DFF")
    private lateinit var page: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var tabs: List<TextView>
    private val anims = ArrayList<android.animation.Animator>()
    private val h = Handler(Looper.getMainLooper())
    private var tab = 0; private var lastVer = -1; private var shownEq = 0.0

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }
    private fun fp(x: Double) = if (x >= 100) "%.2f".format(x) else if (x >= 1) "%.3f".format(x) else if (x >= 0.01) "%.5f".format(x) else "%.3g".format(x)
    private fun money(x: Double) = (if (x < 0) "-" else "") + "\$" + String.format(Locale.US, "%,.2f", abs(x))
    private fun time(ms: Long) = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(ms))
    private fun url(sym: String) = startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bybit.com/trade/usdt/$sym")))

    private fun tv(t: String, sz: Float = 14f, c: Int = TX, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(c); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun glass(r: Int = 20) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0x2EFFFFFF, 0x0AFFFFFF)).apply {
        cornerRadius = dp(r).toFloat(); setStroke(dp(1), 0x33FFFFFF)
    }
    private fun pill(t: String, fg: Int, bg: Int) = tv(t, 12f, fg, true).apply {
        setPadding(dp(10), dp(4), dp(10), dp(4))
        background = GradientDrawable().apply { setColor(bg); cornerRadius = dp(20).toFloat() }
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) }
    }
    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = glass(); setPadding(dp(16), dp(14), dp(16), dp(14)) }
    private fun spacer() = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) }
    private fun row(vararg v: View) = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; v.forEach { addView(it) } }
    private fun header(t: String) = tv(t, 18f, TX, true).apply { layoutParams = lp(22) }

    @SuppressLint("ClickableViewAccessibility")
    private fun press(v: View, onClick: () -> Unit) {
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(.97f).scaleY(.97f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
        v.setOnClickListener { onClick() }
    }
    private fun button(t: String, filled: Boolean, onClick: () -> Unit) = tv(t, 16f, if (filled) DARK else TX, true).apply {
        gravity = Gravity.CENTER; setPadding(0, dp(15), 0, dp(15))
        background = if (filled) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Y, Color.parseColor("#FFC94D"))).apply { cornerRadius = dp(16).toFloat() } else glass(16)
        press(this, onClick)
    }
    private fun dot(c: Int, pulse: Boolean) = View(this).apply {
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
        layoutParams = LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(8) }
        if (pulse) anims.add(ObjectAnimator.ofFloat(this, "alpha", 1f, .25f).apply { duration = 900; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE; start() })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); Store.init(this)
        window.statusBarColor = DARK; window.navigationBarColor = DARK
        val root = FrameLayout(this); root.addView(Aurora(this))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(20)) }
        scroll.addView(page); col.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val bar = LinearLayout(this).apply { background = glass(26); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        tabs = listOf("Сигналы", "Демо", "Бэктест", "Реал", "Настройки").mapIndexed { i, t ->
            tv(t, 13f, MUT, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12)); layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                press(this) { setTab(i) }; bar.addView(this) }
        }
        col.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), 0, dp(14), dp(12)) })
        root.addView(col); setContentView(root)
        setTab(0); loop()
    }

    private fun ensureService() {
        if (!Store.enabled) return
        try { startForegroundService(Intent(this, ScanService::class.java)) } catch (e: Exception) { Scanner.info = "Не удалось запустить службу: ${e.message}" }
    }
    private var askedN = false; private var askedB = false; private var askedO = false
    private fun notifOk() = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    private fun batOk() = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    // Окна с разрешениями выскакивают по очереди сами: уведомления -> работа в фоне -> автозапуск (Tecno/HiOS)
    private fun perms() {
        if (!notifOk() && !askedN) { askedN = true; requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1); return }
        if (!batOk() && !askedB) {
            askedB = true
            try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
            catch (e: Exception) { try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { } }
            return
        }
        if (!Store.oemDone && !askedO) { askedO = true; showOem() }
    }
    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) { super.onRequestPermissionsResult(code, p, r); perms() }

    private fun openOem() {
        val tries = listOf(
            Intent().setComponent(ComponentName("com.transsion.phonemaster", "com.cyin.himgr.autostart.AutoStartActivity")),
            Intent().setComponent(ComponentName("com.transsion.phonemaster", "com.cyin.himgr.whitelist.WhiteListActivity")),
            Intent().setComponent(ComponentName("com.itel.autobootmanager", "com.itel.autobootmanager.activity.AutoBootMgrActivity")),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        for (i in tries) { try { startActivity(i); return } catch (e: Exception) { } }
    }
    private fun showOem() {
        AlertDialog.Builder(this).setTitle("Фон на Tecno / HiOS")
            .setMessage("Чтобы телефон не усыплял сканер:\n\n1. Нажми «Открыть автозапуск» и включи автозапуск для этого приложения (Менеджер телефона / Phone Master).\n2. Настройки → Приложения → Bybit Сканер → Батарея → «Без ограничений».\n3. Открой список недавних приложений и заблокируй карточку приложения (значок замка или потяни карточку вниз).\n\nПосле этого нажми «Готово».")
            .setPositiveButton("Открыть автозапуск") { _, _ -> openOem() }
            .setNeutralButton("Готово") { _, _ -> Store.oemDone = true; Store.save(); Store.ver++; if (tab == 4) render(false) }
            .setNegativeButton("Позже", null).show()
    }
    private fun fixPerms() { askedN = false; askedB = false; if (notifOk() && batOk()) showOem() else perms() }

    override fun onResume() { super.onResume(); ensureService(); perms(); if (tab == 4) render(false) }

    private fun setTab(i: Int) {
        tab = i
        tabs.forEachIndexed { k, v -> v.setTextColor(if (k == i) Y else MUT)
            v.background = if (k == i) GradientDrawable().apply { setColor(0x26F7A600); cornerRadius = dp(20).toFloat() } else null }
        scroll.scrollTo(0, 0); render(true)
    }

    private fun loop() {
        val v = Store.ver * 31 + (System.currentTimeMillis() / 30000).toInt()
        if (v != lastVer && tab != 3 && tab != 4) { lastVer = v; render(false) }
        h.postDelayed({ loop() }, 2000)
    }
    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }

    private fun render(anim: Boolean) {
        anims.forEach { it.cancel() }; anims.clear()
        val y = scroll.scrollY; page.removeAllViews()
        when (tab) { 0 -> signals(); 1 -> demo(); 2 -> test(); 3 -> live(); else -> settings() }
        if (anim) for (i in 0 until page.childCount) {
            val c = page.getChildAt(i); c.alpha = 0f; c.translationY = dp(22).toFloat()
            c.animate().alpha(1f).translationY(0f).setStartDelay(minOf(i, 10) * 45L).setDuration(380).setInterpolator(DecelerateInterpolator()).start()
        } else scroll.post { scroll.scrollTo(0, y) }
    }

    private fun toggle() {
        Store.enabled = !Store.enabled; Store.save()
        val i = Intent(this, ScanService::class.java)
        if (Store.enabled) startForegroundService(i) else { stopService(i); Watchdog.cancelAll(this); Scanner.info = "Остановлен" }
        Store.ver++; render(false)
    }

    private fun signals() {
        page.addView(tv("Сигналы", 30f, TX, true))
        val on = Store.enabled; val ok = Scanner.online
        page.addView(row(dot(if (!on) MUT else if (ok) G else R, on && ok), tv(if (on) Scanner.info else "Сканер остановлен", 13f, MUT)), lp(4))
        val age = (System.currentTimeMillis() - Scanner.lastOk) / 60000
        if (on && Scanner.lastOk > 0 && age >= 5) page.addView(card().apply { addView(tv("⚠ Данные не обновлялись $age мин. Возможно, система остановила службу. Нажми «Обновить сейчас» и выбери «Без ограничений» для батареи в Настройках.", 13f, OR)) }, lp(10))
        page.addView(button(if (on) "Остановить сканер" else "Запустить сканер", !on) { toggle() }, lp(14))
        if (on) page.addView(button("Обновить сейчас", false) { ensureService(); Scanner.kick = true; Scanner.info = "Сканирую рынок…"; Store.ver++; render(false) }, lp(10))
        val l = Scanner.last
        if (l.isEmpty()) page.addView(card().apply { addView(tv(if (on) "Подходящих монет пока нет. Рынок проверяется каждые 2 минуты, уведомление придёт само." else "Запусти сканер, и приложение начнёт искать входы в фоне.", 14f, MUT)) }, lp(16))
        l.forEach { s ->
            val c = card(); val mins = (s.closeAt - System.currentTimeMillis()) / 60000.0
            c.addView(row(tv(s.sym.removeSuffix("USDT"), 19f, TX, true), tv("/USDT", 13f, MUT).apply { setPadding(dp(3), 0, 0, 0) }, spacer(),
                pill(if (s.long) "ЛОНГ" else "ШОРТ", if (s.long) G else R, if (s.long) 0x2220B26C else 0x22EF454A)))
            val st = when (s.st) { "signal" -> pill("Вход сейчас", DARK, Y); "soon" -> pill("Скоро · ${Math.max(0, Math.ceil(mins).toInt())} мин", OR, 0x26FF9F43); else -> pill("Подход", BL, 0x223B82F6) }
            c.addView(row(st, pill("Объём ×" + "%.1f".format(s.vr), if (s.vr >= 1.5) G else MUT, 0x1AFFFFFF)), lp(10))
            c.addView(tv(s.note, 13f, TX), lp(8))
            c.addView(tv("Цена ${fp(s.price)}  ·  EMA 50 ${fp(s.e5)}  ·  " + (if (s.sd >= 0) "+" else "") + "%.2f".format(s.sd) + "%", 12f, MUT), lp(6))
            press(c) { url(s.sym) }; page.addView(c, lp(10))
        }
    }

    private fun demo() {
        page.addView(tv("Демо-торговля", 30f, TX, true))
        if (Store.enabled && !Scanner.online) page.addView(card().apply { addView(tv("⏸ Нет связи с Bybit. Демо на паузе. Когда сеть вернётся, всё пересчитается по истории цен.", 13f, OR)) }, lp(10))
        if (Demo.dayLimitHit()) page.addView(card().apply { addView(tv("🛑 Дневной лимит убытка достигнут. Новые демо-сделки откроются завтра.", 13f, R)) }, lp(10))
        val eq = Demo.equity(); val pnl = eq - Store.deposit
        val wins = Store.closed.count { it.pnl > 0 }
        val big = tv(money(shownEq), 36f, TX, true)
        val c = card().apply { background = glass(26); setPadding(dp(20), dp(18), dp(20), dp(18)) }
        c.addView(tv("Эквити демо-счёта", 13f, MUT)); c.addView(big)
        c.addView(tv((if (pnl >= 0) "+" else "") + money(pnl).replace("-", "−") + "  (" + (if (pnl >= 0) "+" else "") + "%.2f".format(pnl / Store.deposit * 100) + "%) от депозита " + money(Store.deposit), 14f, if (pnl >= 0) G else R, true), lp(2))
        fun stat(v: String, l: String) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            addView(tv(v, 18f, TX, true)); addView(tv(l, 12f, MUT)) }
        c.addView(row(stat("${Store.closed.size}", "сделок"), stat(if (Store.closed.isEmpty()) "—" else "${wins * 100 / Store.closed.size}%", "винрейт"), stat("${Store.open.size}/${Store.maxPos}", "открыто")), lp(16))
        page.addView(c, lp(12))
        val cl = synchronized(Store) { Store.closed.toList() }
        if (cl.isNotEmpty()) {
            fun grp(name: String, f: (Trade) -> Boolean): String { val g = cl.filter(f); return if (g.isEmpty()) "$name: —" else "$name: ${g.size} сд., ${g.count { it.pnl > 0 } * 100 / g.size}%" }
            page.addView(card().apply {
                addView(tv("Винрейт по группам", 13f, MUT))
                addView(tv(grp("Объём ×1.5+") { it.vr >= 1.5 } + "   ·   " + grp("Объём ниже") { it.vr < 1.5 }, 13f, TX), lp(4))
                addView(tv(grp("Лонг") { it.long } + "   ·   " + grp("Шорт") { !it.long }, 13f, TX), lp(2))
            }, lp(10))
        }
        ValueAnimator.ofFloat(shownEq.toFloat(), eq.toFloat()).apply { duration = 700; interpolator = DecelerateInterpolator()
            addUpdateListener { big.text = money((it.animatedValue as Float).toDouble()) }; start(); anims.add(this) }
        shownEq = eq

        page.addView(header("Открытые позиции"))
        val open = synchronized(Store) { Store.open.toList() }
        if (open.isEmpty()) page.addView(tv("Нет открытых позиций. Демо откроет сделку на следующем сигнале «Вход сейчас».", 13f, MUT), lp(6))
        open.forEach { p ->
            val u = Demo.upnl(p); val k = card()
            k.addView(row(tv(p.sym.removeSuffix("USDT"), 17f, TX, true), pill(if (p.long) "ЛОНГ" else "ШОРТ", if (p.long) G else R, if (p.long) 0x2220B26C else 0x22EF454A), spacer(), tv((if (u >= 0) "+" else "") + money(u).replace("-", "−"), 17f, if (u >= 0) G else R, true)))
            k.addView(tv("Вход ${fp(p.entry)} → сейчас ${fp(p.last)}", 13f, TX), lp(8))
            k.addView(tv((if (p.stage == 1) "🔒 " else "") + "Стоп ${fp(p.sl)}  ·  Тейк ${fp(p.tp)}  ·  с ${time(p.openedAt)}", 12f, MUT), lp(4))
            page.addView(k, lp(8))
        }

        page.addView(header("История"))
        if (Store.closed.isEmpty()) page.addView(tv("Закрытых сделок пока нет.", 13f, MUT), lp(6))
        Store.closed.take(30).forEach { t ->
            val k = card().apply { setPadding(dp(16), dp(11), dp(16), dp(11)) }
            val win = t.pnl >= 0
            k.addView(row(tv(t.sym.removeSuffix("USDT"), 15f, TX, true), pill(t.reason, if (t.pnl >= 0) G else R, 0x1AFFFFFF), spacer(),
                tv((if (win) "+" else "") + money(t.pnl).replace("-", "−"), 15f, if (win) G else R, true)))
            k.addView(tv("${if (t.long) "Лонг" else "Шорт"} ${fp(t.entry)} → ${fp(t.exit)}  ·  ${time(t.closedAt)}", 12f, MUT), lp(4))
            page.addView(k, lp(8))
        }
        page.addView(tv("Вход по сигналу «Вход сейчас» по текущей цене, стоп за хвостом свечи, тейк ${Store.rr}R, риск ${Store.riskPct}% счёта, комиссия 0,055% с каждой стороны. На +1R фиксируется ${Store.partial.toInt()}% позиции, стоп уходит в безубыток, остаток ведётся по EMA 50. Дневной лимит убытка ${Store.dayLoss}%. Проверка по 5-минутным свечам; если в свече задеты стоп и цель, считается стоп. Это симуляция, а не гарантия результата.", 12f, MUT), lp(18))
        page.addView(button("Сбросить демо-счёт", false) {
            AlertDialog.Builder(this).setMessage("Удалить все демо-сделки и вернуть депозит?").setPositiveButton("Сбросить") { _, _ -> Demo.reset(); shownEq = 0.0; render(false) }.setNegativeButton("Отмена", null).show()
        }, lp(16))
    }

    private fun statView(v: String, l: String, c: Int = TX) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f); addView(tv(v, 17f, c, true)); addView(tv(l, 11f, MUT)) }

    private fun test() {
        page.addView(tv("Бэктест", 30f, TX, true))
        page.addView(tv("Прогон твоих правил по истории: винрейт, ожидание на сделку и какие фильтры реально помогают. Результат в R (1R = размер риска на сделку).", 13f, MUT), lp(4))
        page.addView(button(if (Bt.running) "Идёт расчёт…" else "Запустить бэктест (60 монет, ~80 дней)", !Bt.running) {
            if (!Bt.running) { Bt.run(Store.cfg(), 60, 2); Store.ver++; render(false) } }, lp(14))
        if (Bt.status.isNotEmpty()) page.addView(tv(Bt.status, 13f, MUT), lp(8))
        val res = Bt.results
        val best = res.filter { it.n >= 20 }.maxByOrNull { it.exp }
        res.forEach { r ->
            val k = card()
            k.addView(row(tv(r.name, 14f, TX, true).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }, if (r === best) pill("лучшее", DARK, Y) else View(this)))
            if (r.n == 0) k.addView(tv("Сделок не найдено", 13f, MUT), lp(6)) else {
                k.addView(row(statView("${r.n}", "сделок"), statView("%.0f".format(r.win) + "%", "винрейт", if (r.win >= 50) G else TX),
                    statView("%+.2f".format(r.exp) + "R", "ожидание", if (r.exp > 0) G else R), statView("%+.1f".format(r.total) + "R", "итог", if (r.total > 0) G else R)), lp(10))
                k.addView(tv("Профит-фактор ${"%.2f".format(r.pf)} · макс. просадка ${"%.1f".format(r.dd)}R" +
                    (if (r.name.startsWith("Мои настройки (")) " · ≈ " + "%+.1f".format(r.total * Store.riskPct) + "% депозита при риске ${Store.riskPct}%" else ""), 12f, MUT), lp(8))
            }
            page.addView(k, lp(8))
        }
        if (res.isNotEmpty()) page.addView(tv("Как читать: ожидание выше нуля значит, что правило в среднем зарабатывает. Смотри не только на винрейт. Ограничения: история около 80 дней по часовым свечам, внутри свечи сначала считается стоп, нет проскальзывания и funding, берутся только монеты, торгующиеся сейчас. Меньше 100 сделок это слабая статистика. Прошлые результаты не гарантируют будущих.", 12f, MUT), lp(14))
    }

    private fun confirm(msg: String, ok: String, run: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg).setPositiveButton(ok) { _, _ -> run() }.setNegativeButton("Отмена", null).show()
    }
    private fun bg(f: () -> Unit) {
        Thread { try { f() } catch (e: Throwable) { Live.status = "Ошибка: ${e.message?.take(150)}" }; runOnUiThread { Store.ver++; render(false) } }.start()
    }
    private fun input(label: String, value: String, hnt: String = "", secret: Boolean = false, num: Boolean = false): Pair<LinearLayout, EditText> {
        val k = card().apply { setPadding(dp(16), dp(12), dp(16), dp(12)) }
        k.addView(tv(label, 13f, MUT))
        val et = EditText(this).apply {
            setText(value); hint = hnt; setHintTextColor(MUT); setTextColor(TX); textSize = 16f; background = null; setPadding(0, dp(4), 0, 0); setSingleLine()
            inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                else if (num) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        k.addView(et); return Pair(k, et)
    }

    private fun live() {
        page.addView(tv("Реальная торговля", 30f, TX, true))
        page.addView(card().apply { addView(tv("⚠ Это настоящие деньги. Стратегия не гарантирует прибыль, убыток возможен, включая потерю всего вложенного. Эту часть приложения я не мог проверить на живой бирже, поэтому сначала обязательно прогони её на Testnet с маленькими суммами. Ключ создай только с правом торговли контрактами и БЕЗ права вывода средств. Ключи Testnet и реального счёта разные.", 13f, OR)) }, lp(10))
        page.addView(button("Сеть: " + if (Store.testnet) "Testnet (тест)" else "РЕАЛЬНЫЕ ДЕНЬГИ", false) {
            if (Store.testnet) confirm("Переключить на РЕАЛЬНЫЙ счёт Bybit? Автоторговля будет выключена, ключи нужно ввести заново и проверить.", "Переключить") {
                Store.testnet = false; Store.liveOn = false; Live.verified = false; Live.status = "Не подключено"; Store.save(); Store.ver++; render(false) }
            else { Store.testnet = true; Store.liveOn = false; Live.verified = false; Live.status = "Не подключено"; Store.save(); Store.ver++; render(false) }
        }, lp(12))
        val kIn = input("API ключ", "", if (Store.apiKey().isEmpty()) "вставь ключ" else "сохранён ••••" + Store.apiKey().takeLast(4))
        val sIn = input("API секрет", "", if (Store.apiSecret().isEmpty()) "вставь секрет" else "сохранён ••••••••", secret = true)
        page.addView(kIn.first, lp(10)); page.addView(sIn.first, lp(8))
        page.addView(button("Сохранить ключи и проверить", true) {
            Store.setKeys(kIn.second.text.toString().trim(), sIn.second.text.toString().trim())
            Live.verified = false; Live.status = "Проверяю подключение…"; render(false); bg { Live.check() }
        }, lp(10))
        page.addView(card().apply {
            addView(tv("Статус", 13f, MUT)); addView(tv(Live.status, 14f, if (Live.verified) G else TX, true), lp(2))
            if (Live.equity > 0) addView(tv("Эквити: " + money(Live.equity), 13f, TX), lp(4))
            if (Live.err.isNotEmpty()) addView(tv("Ошибка: " + Live.err, 12f, R), lp(4))
            addView(tv("Автоторговля: " + (if (Store.liveOn) "ВКЛЮЧЕНА" else "выключена") + "   ·   за день " + money(Store.lDayPnl), 13f, if (Store.liveOn) Y else MUT, true), lp(6))
            if (Store.liveOn && !Store.enabled) addView(tv("Запусти сканер на вкладке «Сигналы», без него сделки не открываются.", 12f, OR), lp(4))
        }, lp(10))
        val defs = listOf(
            Triple("Риск на сделку, % эквити", Store.lRisk, { v: Double -> Store.lRisk = v.coerceIn(0.05, 5.0) }),
            Triple("Макс. открытых позиций", Store.lMaxPos.toDouble(), { v: Double -> Store.lMaxPos = v.toInt().coerceIn(1, 10) }),
            Triple("Макс. плечо", Store.lLev.toDouble(), { v: Double -> Store.lLev = v.toInt().coerceIn(1, 20) }),
            Triple("Дневной лимит убытка, % эквити", Store.lDay, { v: Double -> Store.lDay = v.coerceIn(0.5, 20.0) }))
        val ed = defs.map { (l, v, s) -> val p = input(l, v.toString().removeSuffix(".0"), num = true); page.addView(p.first, lp(8)); Pair(p.second, s) }
        page.addView(button("Сохранить параметры", false) {
            ed.forEach { (e, s) -> e.text.toString().replace(',', '.').toDoubleOrNull()?.let { s(it) } }
            Store.save(); Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        }, lp(10))
        if (!Store.liveOn) page.addView(button("Включить автоторговлю", true) {
            if (!Live.verified) Toast.makeText(this, "Сначала сохрани ключи и пройди проверку подключения", Toast.LENGTH_LONG).show()
            else confirm("Включить автоторговлю на " + (if (Store.testnet) "TESTNET" else "РЕАЛЬНОМ счёте") + "? Приложение само будет открывать сделки по сигналам «Вход сейчас» с риском ${Store.lRisk}% эквити на сделку. Убытки возможны.", "Включить") {
                Store.liveOn = true; Store.save(); Store.ver++; ensureService(); render(false) }
        }, lp(14))
        else page.addView(button("Выключить автоторговлю", false) { Store.liveOn = false; Store.save(); Store.ver++; render(false) }, lp(14))
        page.addView(button("🛑 Закрыть все позиции и остановить", false) {
            confirm("Закрыть ВСЕ открытые позиции на бирже по рынку, отменить ордера и выключить автоторговлю?", "Закрыть всё") { bg { Live.panic() } }
        }.apply { setTextColor(R) }, lp(10))
        page.addView(header("Открытые позиции на бирже"))
        if (Live.positions.isEmpty()) page.addView(tv("Нет открытых позиций", 13f, MUT), lp(6)) else Live.positions.forEach { page.addView(tv(it, 13f, TX), lp(6)) }
        page.addView(header("Журнал"))
        if (Store.llog.isEmpty()) page.addView(tv("Пока пусто", 13f, MUT), lp(6))
        Store.llog.take(20).forEach { page.addView(tv(it, 12f, MUT), lp(4)) }
        page.addView(tv("Стоп и тейк выставляются на бирже вместе с ордером, поэтому защищают позицию, даже если телефон оффлайн. Фиксация на +1R и перенос стопа делаются приложением, когда оно онлайн. Нужен режим позиции One-Way. Остаток по EMA 50 в реальной торговле не ведётся, только стопы и тейк.", 12f, MUT), lp(16))
    }

    private fun settings() {
        page.addView(tv("Настройки", 30f, TX, true))
        page.addView(card().apply {
            addView(tv("Разрешения для работы в фоне", 15f, TX, true))
            fun line(ok: Boolean, t: String) = addView(tv((if (ok) "✅ " else "❌ ") + t, 13f, if (ok) G else OR), lp(6))
            line(notifOk(), "Уведомления"); line(batOk(), "Батарея: без ограничений"); line(Store.oemDone, "Автозапуск и блокировка в недавних (отмечено тобой)")
            addView(button("Настроить разрешения", true) { fixPerms() }, lp(12))
        }, lp(10))
        val sw = ArrayList<Pair<Switch, (Boolean) -> Unit>>()
        fun toggle(label: String, v: Boolean, set: (Boolean) -> Unit) {
            val s = Switch(this).apply { isChecked = v }
            val k = card().apply { setPadding(dp(16), dp(10), dp(16), dp(10)) }
            k.addView(row(tv(label, 14f, TX).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }, s))
            sw.add(Pair(s, set)); page.addView(k, lp(8))
        }
        page.addView(header("Фильтры и управление сделкой"))
        toggle("Фильтр BTC: не против тренда биткоина", Store.btcOn) { Store.btcOn = it }
        toggle("Тренд 4Ч должен совпадать", Store.htfOn) { Store.htfOn = it }
        toggle("Не входить перед funding не в твою пользу", Store.fundOn) { Store.fundOn = it }
        toggle("Стоп в безубыток на +1R", Store.beOn) { Store.beOn = it }
        toggle("Остаток вести по EMA 50", Store.trail) { Store.trail = it }
        val defs = listOf(
            Triple("Мин. оборот за 24ч, млн \$", Store.minVolM, { v: Double -> Store.minVolM = v }),
            Triple("Мин. всплеск объёма, × от среднего (0 = выкл)", Store.minVr, { v: Double -> Store.minVr = v }),
            Triple("Мин. сила тренда ADX (0 = выкл)", Store.adxMin, { v: Double -> Store.adxMin = v }),
            Triple("«Скоро»: за сколько минут до закрытия свечи", Store.win.toDouble(), { v: Double -> Store.win = v.toInt().coerceIn(1, 59) }),
            Triple("Макс. отход цены от EMA 50, %", Store.near, { v: Double -> Store.near = v }),
            Triple("Мин. размер стопа, % от цены", Store.minStop, { v: Double -> Store.minStop = v }),
            Triple("Макс. размер стопа, % от цены", Store.maxStop, { v: Double -> Store.maxStop = v }),
            Triple("Тейк-профит, R (кратно риску)", Store.rr, { v: Double -> Store.rr = v }),
            Triple("Фиксировать на +1R, % позиции (0 = выкл)", Store.partial, { v: Double -> Store.partial = v.coerceIn(0.0, 90.0) }),
            Triple("Депозит демо, \$ (применится после сброса)", Store.deposit, { v: Double -> Store.deposit = v }),
            Triple("Риск на сделку, % счёта", Store.riskPct, { v: Double -> Store.riskPct = v }),
            Triple("Макс. открытых позиций", Store.maxPos.toDouble(), { v: Double -> Store.maxPos = v.toInt().coerceIn(1, 20) }),
            Triple("Дневной лимит убытка, % счёта (0 = выкл)", Store.dayLoss, { v: Double -> Store.dayLoss = v }),
            Triple("Мин. тело свечи в долях ATR (0 = выкл). Отсекает доджи и «болтанку» у EMA 50", Store.minBody, { v: Double -> Store.minBody = v }),
            Triple("Направление: 0 = лонг и шорт, 1 = только лонг, 2 = только шорт", Store.dirMode.toDouble(), { v: Double -> Store.dirMode = v.toInt().coerceIn(0, 2) })
        )
        val edits = ArrayList<Pair<EditText, (Double) -> Unit>>()
        page.addView(header("Параметры"))
        defs.forEach { (label, value, setter) ->
            val k = card().apply { setPadding(dp(16), dp(12), dp(16), dp(12)) }
            k.addView(tv(label, 13f, MUT))
            val et = EditText(this).apply { setText(value.toString().removeSuffix(".0")); setTextColor(TX); textSize = 18f
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; background = null; setPadding(0, dp(4), 0, 0) }
            k.addView(et); edits.add(Pair(et, setter)); page.addView(k, lp(8))
        }
        page.addView(button("Сохранить", true) {
            sw.forEach { (s, set) -> set(s.isChecked) }
            edits.forEach { (et, set) -> et.text.toString().replace(',', '.').toDoubleOrNull()?.let { if (it >= 0) set(it) } }
            Store.save(); Store.ver++; Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        }, lp(16))
        page.addView(tv("Сканер и демо-счёт работают сами: данные обновляются каждые 2 минуты, а после перезагрузки телефона служба запускается заново, если она была включена. Без интернета демо ставится на паузу и после возвращения связи пересчитывается по истории. Новости и экономический календарь приложение не учитывает: в важные дни лучше отключить сканер.", 12f, MUT), lp(16))
    }
}
