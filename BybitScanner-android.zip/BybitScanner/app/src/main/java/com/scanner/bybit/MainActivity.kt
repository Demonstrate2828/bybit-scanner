package com.scanner.bybit

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var list: LinearLayout
    private lateinit var btn: Button
    private var on = false
    private val h = Handler(Looper.getMainLooper())
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0a0e14")); setPadding(dp(16), dp(40), dp(16), dp(16)) }
        root.addView(TextView(this).apply { text = "Bybit EMA-сканер 1H"; textSize = 22f; setTextColor(Color.WHITE) })
        btn = Button(this).apply { text = "Запустить сканер"; setOnClickListener { toggle() } }
        root.addView(btn)
        root.addView(Button(this).apply {
            text = "Разрешить работу в фоне"
            setOnClickListener { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        })
        info = TextView(this).apply { setTextColor(Color.parseColor("#8497ad")); setPadding(0, dp(8), 0, dp(8)) }
        root.addView(info)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) })
        setContentView(root)
        tick()
    }

    private fun toggle() {
        on = !on
        val i = Intent(this, ScanService::class.java)
        if (on) startForegroundService(i) else { stopService(i); Scanner.info = "Остановлен" }
        btn.text = if (on) "Остановить сканер" else "Запустить сканер"
    }

    private fun tick() {
        info.text = Scanner.info
        list.removeAllViews()
        val rows = Scanner.last
        if (rows.isEmpty()) list.addView(TextView(this).apply { text = "Сигналов пока нет. Запусти сканер и жди уведомлений."; setTextColor(Color.GRAY) })
        rows.forEach { s ->
            val tag = when (s.st) { "signal" -> "ВХОД СЕЙЧАС"; "soon" -> "СКОРО (~${Math.ceil(s.mins).toInt()} мин)"; else -> "Подход" }
            list.addView(TextView(this).apply {
                text = (if (s.long) "🟢 ЛОНГ " else "🔴 ШОРТ ") + s.sym + " · " + tag + "\n" + s.note + "\nЦена ${s.price} · EMA 50 ${s.e5}"
                setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#121923")); gravity = Gravity.START
                setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
                setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bybit.com/trade/usdt/${s.sym}"))) }
            })
        }
        h.postDelayed({ tick() }, 3000)
    }
}
