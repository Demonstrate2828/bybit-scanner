package com.scanner.bybit

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

// Фон: медленно плывущие цветные пятна. Поверх них лежат матовые «стеклянные» карточки.
class Aurora(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val cols = intArrayOf(0x66F7A600, 0x5520B26C, 0x553B82F6)
    private val anim = ValueAnimator.ofFloat(0f, 6.2832f).apply {
        duration = 26000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        cv.drawColor(Color.parseColor("#0B0E11"))
        val w = width.toFloat(); val h = height.toFloat()
        for (i in 0..2) {
            val a = t + i * 2.1f
            val cx = w * (0.5f + 0.45f * sin(a)); val cy = h * (0.15f + i * 0.3f + 0.1f * cos(a * 1.3f)); val r = w * 0.85f
            p.shader = RadialGradient(cx, cy, r, cols[i], cols[i] and 0xFFFFFF, Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, r, p)
        }
    }
}

class MainActivity : Activity() {
    private val Y = Color.parseColor("#F7A600"); private val G = Color.parseColor("#20B26C"); private val R = Color.parseColor("#EF454A")
    private val MUT = Color.parseColor("#9AA4B2"); private val TX = Color.parseColor("#F2F4F7"); private val DARK = Color.parseColor("#0B0E11")
    private val OR = Color.parseColor("#FF9F43"); private val BL = Color.parseColor("#5B9DFF")
    private lateinit var page: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var tabs: List<TextView>
    private val anims = ArrayList<android.animation.Animator>()
    private val h = Handler(Looper.getMainLooper())
    private var tab = 0; private var lastVer = -1; private var shownEq = 0.0

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }
    private fun fp(x: Double) = if (x >= 100) "%.2f".format(x) else if (x >= 1) "%.3f".format(x) else if (x >= 0.01) "%.5f".format(x) else "%.3g".format(x)
    private fun money(x: Double) = (if (x < 0) "-" else "") + "\$" + String.format(Locale.US, "%,.2f", abs(x))
    private fun time(ms: Long) = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(ms))
    private fun url(sym: String) = startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bybit.com/trade/usdt/$sym")))

    private fun tv(t: String, sz: Float = 14f, c: Int = TX, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(c); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun glass(r: Int = 20) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0x2EFFFFFF, 0x0AFFFFFF)).apply {
        cornerRadius = dp(r).toFloat(); setStroke(dp(1), 0x33FFFFFF)
    }
    private fun pill(t: String, fg: Int, bg: Int) = tv(t, 12f, fg, true).apply {
        setPadding(dp(10), dp(4), dp(10), dp(4))
        background = GradientDrawable().apply { setColor(bg); cornerRadius = dp(20).toFloat() }
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) }
    }
    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = glass(); setPadding(dp(16), dp(14), dp(16), dp(14)) }
    private fun spacer() = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) }
    private fun row(vararg v: View) = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; v.forEach { addView(it) } }
    private fun header(t: String) = tv(t, 18f, TX, true).apply { layoutParams = lp(22) }

    @SuppressLint("ClickableViewAccessibility")
    private fun press(v: View, onClick: () -> Unit) {
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(.97f).scaleY(.97f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
        v.setOnClickListener { onClick() }
    }
    private fun button(t: String, filled: Boolean, onClick: () -> Unit) = tv(t, 16f, if (filled) DARK else TX, true).apply {
        gravity = Gravity.CENTER; setPadding(0, dp(15), 0, dp(15))
        background = if (filled) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Y, Color.parseColor("#FFC94D"))).apply { cornerRadius = dp(16).toFloat() } else glass(16)
        press(this, onClick)
    }
    private fun dot(c: Int, pulse: Boolean) = View(this).apply {
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
        layoutParams = LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(8) }
        if (pulse) anims.add(ObjectAnimator.ofFloat(this, "alpha", 1f, .25f).apply { duration = 900; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE; start() })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); Store.init(this)
        window.statusBarColor = DARK; window.navigationBarColor = DARK
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val root = FrameLayout(this); root.addView(Aurora(this))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(20)) }
        scroll.addView(page); col.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val bar = LinearLayout(this).apply { background = glass(26); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        tabs = listOf("Сигналы", "Демо", "Настройки").mapIndexed { i, t ->
            tv(t, 14f, MUT, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12)); layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                press(this) { setTab(i) }; bar.addView(this) }
        }
        col.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), 0, dp(14), dp(12)) })
        root.addView(col); setContentView(root)
        setTab(0); loop()
    }

    private fun setTab(i: Int) {
        tab = i
        tabs.forEachIndexed { k, v -> v.setTextColor(if (k == i) Y else MUT)
            v.background = if (k == i) GradientDrawable().apply { setColor(0x26F7A600); cornerRadius = dp(20).toFloat() } else null }
        scroll.scrollTo(0, 0); render(true)
    }

    private fun loop() {
        val v = Store.ver * 31 + (System.currentTimeMillis() / 30000).toInt()
        if (v != lastVer && tab != 2) { lastVer = v; render(false) }
        h.postDelayed({ loop() }, 2000)
    }
    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }

    private fun render(anim: Boolean) {
        anims.forEach { it.cancel() }; anims.clear()
        val y = scroll.scrollY; page.removeAllViews()
        when (tab) { 0 -> signals(); 1 -> demo(); else -> settings() }
        if (anim) for (i in 0 until page.childCount) {
            val c = page.getChildAt(i); c.alpha = 0f; c.translationY = dp(22).toFloat()
            c.animate().alpha(1f).translationY(0f).setStartDelay(minOf(i, 10) * 45L).setDuration(380).setInterpolator(DecelerateInterpolator()).start()
        } else scroll.post { scroll.scrollTo(0, y) }
    }

    private fun toggle() {
        Store.enabled = !Store.enabled; Store.save()
        val i = Intent(this, ScanService::class.java)
        if (Store.enabled) startForegroundService(i) else { stopService(i); Scanner.info = "Остановлен" }
        Store.ver++; render(false)
    }

    private fun signals() {
        page.addView(tv("Сигналы", 30f, TX, true))
        val on = Store.enabled; val ok = Scanner.online
        page.addView(row(dot(if (!on) MUT else if (ok) G else R, on && ok), tv(if (on) Scanner.info else "Сканер остановлен", 13f, MUT)), lp(4))
        page.addView(button(if (on) "Остановить сканер" else "Запустить сканер", !on) { toggle() }, lp(14))
        val l = Scanner.last
        if (l.isEmpty()) page.addView(card().apply { addView(tv(if (on) "Подходящих монет пока нет. Рынок проверяется каждые 2 минуты, уведомление придёт само." else "Запусти сканер, и приложение начнёт искать входы в фоне.", 14f, MUT)) }, lp(16))
        l.forEach { s ->
            val c = card(); val mins = (s.closeAt - System.currentTimeMillis()) / 60000.0
            c.addView(row(tv(s.sym.removeSuffix("USDT"), 19f, TX, true), tv("/USDT", 13f, MUT).apply { setPadding(dp(3), 0, 0, 0) }, spacer(),
                pill(if (s.long) "ЛОНГ" else "ШОРТ", if (s.long) G else R, if (s.long) 0x2220B26C else 0x22EF454A)))
            val st = when (s.st) { "signal" -> pill("Вход сейчас", DARK, Y); "soon" -> pill("Скоро · ${Math.max(0, Math.ceil(mins).toInt())} мин", OR, 0x26FF9F43); else -> pill("Подход", BL, 0x223B82F6) }
            c.addView(row(st, pill("Объём ×" + "%.1f".format(s.vr), if (s.vr >= 1.5) G else MUT, 0x1AFFFFFF)), lp(10))
            c.addView(tv(s.note, 13f, TX), lp(8))
            c.addView(tv("Цена ${fp(s.price)}  ·  EMA 50 ${fp(s.e5)}  ·  " + (if (s.sd >= 0) "+" else "") + "%.2f".format(s.sd) + "%", 12f, MUT), lp(6))
            press(c) { url(s.sym) }; page.addView(c, lp(10))
        }
    }

    private fun demo() {
        page.addView(tv("Демо-торговля", 30f, TX, true))
        if (Store.enabled && !Scanner.online) page.addView(card().apply { addView(tv("⏸ Нет связи с Bybit. Демо на паузе. Когда сеть вернётся, всё пересчитается по истории цен.", 13f, OR)) }, lp(10))
        val eq = Demo.equity(); val pnl = eq - Store.deposit
        val wins = Store.closed.count { it.pnl > 0 }
        val big = tv(money(shownEq), 36f, TX, true)
        val c = card().apply { background = glass(26); setPadding(dp(20), dp(18), dp(20), dp(18)) }
        c.addView(tv("Эквити демо-счёта", 13f, MUT)); c.addView(big)
        c.addView(tv((if (pnl >= 0) "+" else "") + money(pnl).replace("-", "−") + "  (" + (if (pnl >= 0) "+" else "") + "%.2f".format(pnl / Store.deposit * 100) + "%) от депозита " + money(Store.deposit), 14f, if (pnl >= 0) G else R, true), lp(2))
        fun stat(v: String, l: String) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            addView(tv(v, 18f, TX, true)); addView(tv(l, 12f, MUT)) }
        c.addView(row(stat("${Store.closed.size}", "сделок"), stat(if (Store.closed.isEmpty()) "—" else "${wins * 100 / Store.closed.size}%", "винрейт"), stat("${Store.open.size}/5", "открыто")), lp(16))
        page.addView(c, lp(12))
        ValueAnimator.ofFloat(shownEq.toFloat(), eq.toFloat()).apply { duration = 700; interpolator = DecelerateInterpolator()
            addUpdateListener { big.text = money((it.animatedValue as Float).toDouble()) }; start(); anims.add(this) }
        shownEq = eq

        page.addView(header("Открытые позиции"))
        val open = synchronized(Store) { Store.open.toList() }
        if (open.isEmpty()) page.addView(tv("Нет открытых позиций. Демо откроет сделку на следующем сигнале «Вход сейчас».", 13f, MUT), lp(6))
        open.forEach { p ->
            val u = Demo.upnl(p); val k = card()
            k.addView(row(tv(p.sym.removeSuffix("USDT"), 17f, TX, true), pill(if (p.long) "ЛОНГ" else "ШОРТ", if (p.long) G else R, if (p.long) 0x2220B26C else 0x22EF454A), spacer(), tv((if (u >= 0) "+" else "") + money(u).replace("-", "−"), 17f, if (u >= 0) G else R, true)))
            k.addView(tv("Вход ${fp(p.entry)} → сейчас ${fp(p.last)}", 13f, TX), lp(8))
            k.addView(tv("Стоп ${fp(p.sl)}  ·  Тейк ${fp(p.tp)}  ·  с ${time(p.openedAt)}", 12f, MUT), lp(4))
            page.addView(k, lp(8))
        }

        page.addView(header("История"))
        if (Store.closed.isEmpty()) page.addView(tv("Закрытых сделок пока нет.", 13f, MUT), lp(6))
        Store.closed.take(30).forEach { t ->
            val k = card().apply { setPadding(dp(16), dp(11), dp(16), dp(11)) }
            val win = t.pnl >= 0
            k.addView(row(tv(t.sym.removeSuffix("USDT"), 15f, TX, true), pill(t.reason, if (t.reason == "TP") G else if (t.reason == "SL") R else MUT, 0x1AFFFFFF), spacer(),
                tv((if (win) "+" else "") + money(t.pnl).replace("-", "−"), 15f, if (win) G else R, true)))
            k.addView(tv("${if (t.long) "Лонг" else "Шорт"} ${fp(t.entry)} → ${fp(t.exit)}  ·  ${time(t.closedAt)}", 12f, MUT), lp(4))
            page.addView(k, lp(8))
        }
        page.addView(tv("Вход по сигналу «Вход сейчас» по текущей цене. Стоп за хвостом сигнальной свечи, тейк ${Store.rr}R, риск ${Store.riskPct}% счёта, комиссия 0,055% с каждой стороны, до 5 позиций. Проверка по 5-минутным свечам; если в свече задеты и стоп, и тейк, считается стоп. Это симуляция, а не гарантия результата.", 12f, MUT), lp(18))
        page.addView(button("Сбросить демо-счёт", false) {
            AlertDialog.Builder(this).setMessage("Удалить все демо-сделки и вернуть депозит?").setPositiveButton("Сбросить") { _, _ -> Demo.reset(); shownEq = 0.0; render(false) }.setNegativeButton("Отмена", null).show()
        }, lp(16))
    }

    private fun settings() {
        page.addView(tv("Настройки", 30f, TX, true))
        val defs = listOf(
            Triple("Мин. оборот за 24ч, млн \$", Store.minVolM, { v: Double -> Store.minVolM = v }),
            Triple("Мин. всплеск объёма, × от среднего (0 = выкл)", Store.minVr, { v: Double -> Store.minVr = v }),
            Triple("«Скоро»: за сколько минут до закрытия свечи", Store.win.toDouble(), { v: Double -> Store.win = v.toInt().coerceIn(1, 59) }),
            Triple("Макс. отход цены от EMA 50, %", Store.near, { v: Double -> Store.near = v }),
            Triple("Депозит демо, \$ (применится после сброса)", Store.deposit, { v: Double -> Store.deposit = v }),
            Triple("Риск на сделку, % счёта", Store.riskPct, { v: Double -> Store.riskPct = v }),
            Triple("Тейк-профит, R (кратно риску)", Store.rr, { v: Double -> Store.rr = v })
        )
        val edits = ArrayList<Pair<EditText, (Double) -> Unit>>()
        defs.forEach { (label, value, setter) ->
            val k = card().apply { setPadding(dp(16), dp(12), dp(16), dp(12)) }
            k.addView(tv(label, 13f, MUT))
            val et = EditText(this).apply { setText(value.toString().removeSuffix(".0")); setTextColor(TX); textSize = 18f
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; background = null; setPadding(0, dp(4), 0, 0) }
            k.addView(et); edits.add(Pair(et, setter)); page.addView(k, lp(10))
        }
        page.addView(button("Сохранить", true) {
            edits.forEach { (et, set) -> et.text.toString().replace(',', '.').toDoubleOrNull()?.let { if (it >= 0) set(it) } }
            Store.save(); Store.ver++; Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        }, lp(16))
        page.addView(button("Разрешить работу в фоне", false) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }, lp(10))
        page.addView(tv("Сканер и демо-счёт работают сами: данные обновляются каждые 2 минуты, а после перезагрузки телефона служба запускается заново, если она была включена. Без интернета демо ставится на паузу и после возвращения связи пересчитывается по истории. Чтобы телефон не усыплял приложение, выбери «Без ограничений» в разрешении выше.", 12f, MUT), lp(16))
    }
}
