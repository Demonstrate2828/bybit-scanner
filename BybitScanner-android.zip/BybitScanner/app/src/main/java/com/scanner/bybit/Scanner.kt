package com.scanner.bybit

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

data class Sig(val sym: String, val long: Boolean, val st: String, val price: Double, val e5: Double, val sd: Double,
               val mins: Double, val closeAt: Long, val note: String, val vr: Double, val ext: Double)

object Scanner {
    private val hosts = listOf("https://api.bybit.com", "https://api.bytick.com")
    @Volatile private var hi = 0
    @Volatile var last: List<Sig> = emptyList()
    @Volatile var info = "Не запущен"
    @Volatile var online = true
    @Volatile var lastOk = 0L
    @Volatile var kick = false

    fun get(path: String): JSONObject {
        var err: Exception? = null
        for (a in 0 until hosts.size * 2) {
            val k = (hi + a) % hosts.size
            try {
                val c = URL(hosts[k] + path).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 12000
                val j = JSONObject(c.inputStream.bufferedReader().readText())
                if (j.getInt("retCode") == 0) { hi = k; return j.getJSONObject("result") }
                Thread.sleep(1000)
            } catch (e: Exception) { err = e }
        }
        throw err ?: Exception("Bybit недоступен")
    }

    // 5-минутные свечи от момента start (старые -> новые): для проверки стопа и тейка демо-сделок
    fun klines(sym: String, start: Long): List<DoubleArray> {
        val a = get("/v5/market/kline?category=linear&symbol=$sym&interval=5&start=$start&end=${System.currentTimeMillis()}&limit=1000").getJSONArray("list")
        val out = ArrayList<DoubleArray>()
        for (i in a.length() - 1 downTo 0) {
            val x = a.getJSONArray(i)
            out.add(doubleArrayOf(x.getString(0).toDouble(), x.getString(1).toDouble(), x.getString(2).toDouble(), x.getString(3).toDouble(), x.getString(4).toDouble()))
        }
        return out
    }

    private fun ema(v: DoubleArray, n: Int): DoubleArray {
        val o = DoubleArray(v.size) { Double.NaN }
        if (v.size < n) return o
        var e = 0.0; for (i in 0 until n) e += v[i]; e /= n; o[n - 1] = e
        val k = 2.0 / (n + 1)
        for (i in n until v.size) { e = v[i] * k + e * (1 - k); o[i] = e }
        return o
    }

    private fun analyze(sym: String, raw: JSONArray, win: Int, near: Double, minVr: Double): Sig? {
        val m = raw.length(); if (m < 215) return null
        val t = LongArray(m); val o = DoubleArray(m); val h = DoubleArray(m); val l = DoubleArray(m); val c = DoubleArray(m); val v = DoubleArray(m)
        for (j in 0 until m) {
            val x = raw.getJSONArray(m - 1 - j)
            t[j] = x.getString(0).toLong(); o[j] = x.getString(1).toDouble(); h[j] = x.getString(2).toDouble()
            l[j] = x.getString(3).toDouble(); c[j] = x.getString(4).toDouble(); v[j] = x.getString(5).toDouble()
        }
        val e5 = ema(c, 50); val e2 = ema(c, 200); val n = m - 1; val i = n - 1
        val up = e5[i] > e2[i] && e5[i] > e5[i - 5] && e2[i] > e2[i - 5]
        val dn = e5[i] < e2[i] && e5[i] < e5[i - 5] && e2[i] < e2[i - 5]
        var cr = 0
        for (j in i - 23..i) if ((c[j] > e2[j]) != (c[j - 1] > e2[j - 1])) cr++
        val spread = abs(e5[i] - e2[i]) / e2[i] * 100
        if ((!up && !dn) || spread < 0.3 || cr >= 4) return null   // флэт: не торгуем
        val L = up
        val closeAt = t[n] + 3_600_000L
        val mins = (closeAt - System.currentTimeMillis()) / 60000.0
        val sd = (if (L) c[n] - e5[n] else e5[n] - c[n]) / e5[n] * 100
        val came = (1..3).any { d -> if (L) c[i - d] > e5[i - d] else c[i - d] < e5[i - d] }
        val touchC = if (L) l[i] <= e5[i] else h[i] >= e5[i]
        val confC = if (L) (c[i] > e5[i] && c[i] > o[i]) else (c[i] < e5[i] && c[i] < o[i])
        val touchN = if (L) l[n] <= e5[n] else h[n] >= e5[n]
        val confN = if (L) (c[n] > e5[n] && c[n] > o[n]) else (c[n] < e5[n] && c[n] < o[n])
        // Объём: последняя закрытая свеча (или прогноз текущей) против среднего за 20 свечей
        var s = 0.0; for (j in i - 20 until i) s += v[j]; val avg = s / 20
        val vrC = if (avg > 0) v[i] / avg else 0.0
        val vrN = if (avg > 0) v[n] / Math.max(0.1, (60 - mins) / 60) / avg else 0.0
        val side = if (L) "выше" else "ниже"
        val st: String; val note: String; var vr = vrC; var ext = if (L) l[i] else h[i]
        when {
            touchC && confC && came && sd >= 0 && sd <= near && vrC >= minVr -> {
                st = "signal"; note = "Свеча коснулась EMA 50 и закрылась $side неё. Подтверждение есть."
            }
            mins <= win && touchN && confN && came && sd <= near && vrN >= minVr -> {
                st = "soon"; vr = vrN; ext = if (L) l[n] else h[n]
                note = "До закрытия ~${Math.ceil(mins).toInt()} мин. Касание EMA 50 есть, цена держится $side."
            }
            sd >= -0.1 && sd <= near -> {
                st = "watch"; vr = vrN; note = "Цена в ${"%.2f".format(abs(sd))}% от EMA 50. Ждём касание и подтверждение."
            }
            else -> return null
        }
        return Sig(sym, L, st, c[n], e5[n], sd, mins, closeAt, note, vr, ext)
    }

    private fun ord(s: String) = when (s) { "signal" -> 0; "soon" -> 1; else -> 2 }

    fun scan(win: Int, near: Double, minVolM: Double, minVr: Double): List<Sig> {
        val tk = get("/v5/market/tickers?category=linear").getJSONArray("list")
        val syms = ArrayList<String>()
        for (i in 0 until tk.length()) {
            val x = tk.getJSONObject(i); val s = x.getString("symbol")
            if (s.endsWith("USDT") && !s.contains("-") && x.getString("turnover24h").toDouble() >= minVolM * 1e6) syms.add(s)
        }
        val fails = AtomicInteger(); val ex = Executors.newFixedThreadPool(8)
        try {
            val fs = ex.invokeAll(syms.map { s ->
                Callable<Sig?> {
                    if (fails.get() >= 15) null else try {
                        analyze(s, get("/v5/market/kline?category=linear&symbol=$s&interval=60&limit=300").getJSONArray("list"), win, near, minVr)
                    } catch (e: Exception) { fails.incrementAndGet(); null }
                }
            })
            if (fails.get() >= 15) throw Exception("Связь потеряна")
            return fs.mapNotNull { it.get() }.sortedWith(compareBy<Sig>({ ord(it.st) }, { if (it.st == "watch") abs(it.sd) else it.mins }))
        } finally { ex.shutdown() }
    }
}
