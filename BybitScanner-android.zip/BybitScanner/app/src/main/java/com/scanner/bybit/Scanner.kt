package com.scanner.bybit

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

// Свечи в виде столбцов: время, open, high, low, close, объём
class Cd(a: List<DoubleArray>) {
    val n = a.size
    val t = LongArray(n) { a[it][0].toLong() }
    val o = DoubleArray(n) { a[it][1] }; val h = DoubleArray(n) { a[it][2] }; val l = DoubleArray(n) { a[it][3] }
    val c = DoubleArray(n) { a[it][4] }; val v = DoubleArray(n) { a[it][5] }
}
data class Sig(val sym: String, val long: Boolean, val st: String, val price: Double, val e5: Double, val sd: Double,
               val mins: Double, val closeAt: Long, val note: String, val vr: Double, val adx: Double, val ext: Double)
class Cs(val long: Boolean, val vr: Double, val ext: Double)

object Scanner {
    private val hosts = listOf("https://api.bybit.com", "https://api.bytick.com")
    @Volatile private var hi = 0
    @Volatile var last: List<Sig> = emptyList()
    @Volatile var info = "Не запущен"
    @Volatile var online = true
    @Volatile var lastOk = 0L
    @Volatile var kick = false

    fun get(path: String): JSONObject {
        var err: Exception? = null
        for (a in 0 until hosts.size * 2) {
            val k = (hi + a) % hosts.size
            try {
                val c = URL(hosts[k] + path).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 12000
                val j = JSONObject(c.inputStream.bufferedReader().readText())
                if (j.getInt("retCode") == 0) { hi = k; return j.getJSONObject("result") }
                Thread.sleep(1000)
            } catch (e: Exception) { err = e }
        }
        throw err ?: Exception("Bybit недоступен")
    }

    fun parse(a: JSONArray): List<DoubleArray> {
        val o = ArrayList<DoubleArray>(a.length())
        for (i in a.length() - 1 downTo 0) { val x = a.getJSONArray(i); o.add(DoubleArray(6) { k -> x.getString(k).toDouble() }) }
        return o   // от старых к новым
    }
    fun klines(sym: String, start: Long): List<DoubleArray> =
        parse(get("/v5/market/kline?category=linear&symbol=$sym&interval=5&start=$start&end=${System.currentTimeMillis()}&limit=1000").getJSONArray("list"))

    // Длинная история (несколько страниц по 1000 свечей), от старых к новым
    fun history(sym: String, interval: String, pages: Int): List<DoubleArray> {
        var end = System.currentTimeMillis(); val out = ArrayList<DoubleArray>()
        for (p in 0 until pages) {
            val a = get("/v5/market/kline?category=linear&symbol=$sym&interval=$interval&end=$end&limit=1000").getJSONArray("list")
            if (a.length() == 0) break
            val ch = parse(a); out.addAll(0, ch); end = ch[0][0].toLong() - 1
            if (a.length() < 1000) break
        }
        return out
    }
    private fun closedCd(sym: String, iv: String) = Cd(parse(get("/v5/market/kline?category=linear&symbol=$sym&interval=$iv&limit=300").getJSONArray("list")).dropLast(1))

    fun ema(v: DoubleArray, n: Int): DoubleArray {
        val o = DoubleArray(v.size) { Double.NaN }
        if (v.size < n) return o
        var e = 0.0; for (i in 0 until n) e += v[i]; e /= n; o[n - 1] = e
        val k = 2.0 / (n + 1)
        for (i in n until v.size) { e = v[i] * k + e * (1 - k); o[i] = e }
        return o
    }

    // ADX (Уайлдер, 14): сила тренда
    fun adx(h: DoubleArray, l: DoubleArray, c: DoubleArray, n: Int = 14): DoubleArray {
        val m = h.size; val out = DoubleArray(m) { Double.NaN }
        if (m < 2 * n + 2) return out
        var tr = 0.0; var pd = 0.0; var md = 0.0; val dx = DoubleArray(m)
        for (i in 1 until m) {
            val up = h[i] - h[i - 1]; val dn = l[i - 1] - l[i]
            val t = maxOf(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1]))
            val p = if (up > dn && up > 0) up else 0.0; val q = if (dn > up && dn > 0) dn else 0.0
            if (i <= n) { tr += t; pd += p; md += q } else { tr = tr - tr / n + t; pd = pd - pd / n + p; md = md - md / n + q }
            if (i >= n && tr > 0) { val a = 100 * pd / tr; val b = 100 * md / tr; dx[i] = if (a + b == 0.0) 0.0 else 100 * abs(a - b) / (a + b) }
        }
        var a = 0.0; for (i in n until 2 * n) a += dx[i]; a /= n; out[2 * n - 1] = a
        for (i in 2 * n until m) { a = (a * (n - 1) + dx[i]) / n; out[i] = a }
        return out
    }

    // 1 = рост, -1 = падение, 0 = флэт / нет тренда (правила из инструкции)
    fun trend(c: DoubleArray, e5: DoubleArray, e2: DoubleArray, i: Int): Int {
        val up = e5[i] > e2[i] && e5[i] > e5[i - 5] && e2[i] > e2[i - 5]
        val dn = e5[i] < e2[i] && e5[i] < e5[i - 5] && e2[i] < e2[i - 5]
        var cr = 0
        for (j in i - 23..i) if ((c[j] > e2[j]) != (c[j - 1] > e2[j - 1])) cr++
        if (abs(e5[i] - e2[i]) / e2[i] * 100 < 0.3 || cr >= 4) return 0
        return if (up) 1 else if (dn) -1 else 0
    }
    fun dirSimple(e5: DoubleArray, e2: DoubleArray, j: Int): Int =
        if (e5[j] > e2[j] && e5[j] > e5[j - 3]) 1 else if (e5[j] < e2[j] && e5[j] < e5[j - 3]) -1 else 0

    // Подтверждённый вход по закрытой свече i (общая логика для сканера и бэктеста)
    fun closedSignal(x: Cd, e5: DoubleArray, e2: DoubleArray, ad: DoubleArray, i: Int, cf: Cfg, px: Double): Cs? {
        val tr = trend(x.c, e5, e2, i); if (tr == 0) return null
        val L = tr == 1; val c = x.c
        val sd = (if (L) px - e5[i] else e5[i] - px) / e5[i] * 100
        if (sd < 0 || sd > cf.near) return null
        val came = (1..3).any { d -> if (L) c[i - d] > e5[i - d] else c[i - d] < e5[i - d] }
        val touch = if (L) x.l[i] <= e5[i] else x.h[i] >= e5[i]
        val conf = if (L) (c[i] > e5[i] && c[i] > x.o[i]) else (c[i] < e5[i] && c[i] < x.o[i])
        if (!(came && touch && conf)) return null
        var s = 0.0; for (j in i - 20 until i) s += x.v[j]; val avg = s / 20
        val vr = if (avg > 0) x.v[i] / avg else 0.0
        if (vr < cf.minVr) return null
        if (cf.adxMin > 0 && !(ad[i] >= cf.adxMin)) return null
        return Cs(L, vr, if (L) x.l[i] else x.h[i])
    }

    private fun analyze(sym: String, raw: JSONArray, cf: Cfg): Sig? {
        val x = Cd(parse(raw)); val m = x.n; if (m < 215) return null
        val c = x.c; val e5 = ema(c, 50); val e2 = ema(c, 200); val ad = adx(x.h, x.l, c); val n = m - 1; val i = n - 1
        val tr = trend(c, e5, e2, i); if (tr == 0) return null     // флэт: не торгуем
        val L = tr == 1
        val closeAt = x.t[n] + 3_600_000L
        val mins = (closeAt - System.currentTimeMillis()) / 60000.0
        val sd = (if (L) c[n] - e5[n] else e5[n] - c[n]) / e5[n] * 100
        val came = (1..3).any { d -> if (L) c[i - d] > e5[i - d] else c[i - d] < e5[i - d] }
        val touchN = if (L) x.l[n] <= e5[n] else x.h[n] >= e5[n]
        val confN = if (L) (c[n] > e5[n] && c[n] > x.o[n]) else (c[n] < e5[n] && c[n] < x.o[n])
        var s = 0.0; for (j in i - 20 until i) s += x.v[j]; val avg = s / 20
        val vrN = if (avg > 0) x.v[n] / Math.max(0.1, (60 - mins) / 60) / avg else 0.0
        val adxOk = cf.adxMin <= 0 || ad[i] >= cf.adxMin
        val side = if (L) "выше" else "ниже"
        fun stopOk(ext: Double): Boolean { val p = (abs(c[n] - ext) / c[n] + 0.001) * 100; return p >= cf.minStop && p <= cf.maxStop }
        val cs = closedSignal(x, e5, e2, ad, i, cf, c[n])
        val curExt = if (L) x.l[n] else x.h[n]
        val st: String; val note: String; var vr = vrN; var ext = curExt
        if (cs != null && stopOk(cs.ext)) {
            st = "signal"; vr = cs.vr; ext = cs.ext; note = "Свеча коснулась EMA 50 и закрылась $side неё. Подтверждение есть."
        } else if (mins <= cf.win && touchN && confN && came && sd <= cf.near && vrN >= cf.minVr && adxOk && stopOk(curExt)) {
            st = "soon"; note = "До закрытия ~${Math.ceil(mins).toInt()} мин. Касание EMA 50 есть, цена держится $side."
        } else if (sd >= -0.1 && sd <= cf.near) {
            st = "watch"
            note = if (cs != null) "Сигнал есть, но стоп получается слишком близким или далёким." else "Цена в ${"%.2f".format(abs(sd))}% от EMA 50. Ждём касание и подтверждение."
        } else return null
        return Sig(sym, L, st, c[n], e5[n], sd, mins, closeAt, note, vr, ad[i], ext)
    }

    fun btcDir(): Int { val x = closedCd("BTCUSDT", "60"); return trend(x.c, ema(x.c, 50), ema(x.c, 200), x.n - 1) }
    private fun htfDir(sym: String): Int { val x = closedCd(sym, "240"); return dirSimple(ema(x.c, 50), ema(x.c, 200), x.n - 1) }
    fun trailInfo(sym: String): Triple<Long, Double, Double> { val x = closedCd(sym, "60"); val e = ema(x.c, 50); val i = x.n - 1; return Triple(x.t[i], x.c[i], e[i]) }

    private fun ord(s: String) = when (s) { "signal" -> 0; "soon" -> 1; else -> 2 }

    fun scan(cf: Cfg, minVolM: Double): List<Sig> {
        val tk = get("/v5/market/tickers?category=linear").getJSONArray("list")
        val syms = ArrayList<String>(); val fund = HashMap<String, Pair<Double, Long>>()
        for (i in 0 until tk.length()) {
            val x = tk.getJSONObject(i); val s = x.getString("symbol")
            if (s.endsWith("USDT") && !s.contains("-") && x.getString("turnover24h").toDouble() >= minVolM * 1e6) {
                syms.add(s)
                val fr = x.optString("fundingRate", "").toDoubleOrNull(); val nf = x.optString("nextFundingTime", "").toLongOrNull()
                if (fr != null && nf != null) fund[s] = Pair(fr, nf)
            }
        }
        val fails = AtomicInteger(); val ex = Executors.newFixedThreadPool(8)
        val sigs: List<Sig>
        try {
            val fs = ex.invokeAll(syms.map { s ->
                Callable<Sig?> {
                    if (fails.get() >= 15) null else try {
                        analyze(s, get("/v5/market/kline?category=linear&symbol=$s&interval=60&limit=300").getJSONArray("list"), cf)
                    } catch (e: Exception) { fails.incrementAndGet(); null }
                }
            })
            if (fails.get() >= 15) throw Exception("Связь потеряна")
            sigs = fs.mapNotNull { it.get() }
        } finally { ex.shutdown() }
        // Доп. фильтры только для найденных кандидатов: BTC, тренд 4Ч, funding
        val btc = if (cf.btcOn && sigs.any { it.st != "watch" }) btcDir() else 0
        val now = System.currentTimeMillis()
        return sigs.map { s ->
            if (s.st == "watch") s else {
                var why: String? = null
                if (cf.btcOn && btc == (if (s.long) -1 else 1)) why = "против тренда BTC"
                if (why == null && cf.htfOn && htfDir(s.sym) != (if (s.long) 1 else -1)) why = "против тренда 4Ч"
                val f = fund[s.sym]
                if (why == null && cf.fundOn && f != null && abs(f.first) >= 0.0003 && (if (s.long) f.first > 0 else f.first < 0) && f.second - now in 0L..600_000L)
                    why = "скоро funding не в твою пользу"
                if (why == null) s else s.copy(st = "watch", note = "Сигнал отклонён фильтром: $why.")
            }
        }.sortedWith(compareBy<Sig>({ ord(it.st) }, { if (it.st == "watch") abs(it.sd) else it.mins }))
    }
}
