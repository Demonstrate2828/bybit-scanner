package com.scanner.bybit

import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread
import kotlin.math.abs

data class Res(val name: String, val n: Int, val win: Double, val exp: Double, val total: Double, val pf: Double, val dd: Double)
class Tr(val t: Long, val r: Double)
class BData(val sym: String, val x: Cd, val x4: Cd) {
    val e5 = Scanner.ema(x.c, 50); val e2 = Scanner.ema(x.c, 200); val ad = Scanner.adx(x.h, x.l, x.c)
    val f5 = Scanner.ema(x4.c, 50); val f2 = Scanner.ema(x4.c, 200)
    val idx4 = HashMap<Long, Int>().also { m -> for (k in 0 until x4.n) m[x4.t[k]] = k }
}

// Бэктест: прогоняет те же правила по истории 1Ч-свечей. Результат в R (1R = риск на сделку).
object Bt {
    @Volatile var running = false
    @Volatile var status = ""
    @Volatile var results: List<Res> = emptyList()

    fun run(cfg: Cfg, top: Int, pages: Int) {
        if (running) return
        running = true; results = emptyList(); status = "Загружаю список монет…"; Store.ver++
        thread {
            try {
                val tk = Scanner.get("/v5/market/tickers?category=linear").getJSONArray("list")
                val list = ArrayList<Pair<String, Double>>()
                for (i in 0 until tk.length()) { val x = tk.getJSONObject(i); val s = x.getString("symbol")
                    if (s.endsWith("USDT") && !s.contains("-")) list.add(Pair(s, x.getString("turnover24h").toDouble())) }
                val syms = list.sortedByDescending { it.second }.take(top).map { it.first }
                status = "Загружаю BTC…"; Store.ver++
                val bx = Cd(Scanner.history("BTCUSDT", "60", pages).dropLast(1))
                val b5 = Scanner.ema(bx.c, 50); val b2 = Scanner.ema(bx.c, 200)
                val btc = HashMap<Long, Int>(); for (j in 205 until bx.n) btc[bx.t[j]] = Scanner.trend(bx.c, b5, b2, j)
                val done = AtomicInteger(); val ex = Executors.newFixedThreadPool(6)
                val fs = ex.invokeAll(syms.map { s ->
                    Callable<BData?> {
                        try {
                            val d = BData(s, Cd(Scanner.history(s, "60", pages).dropLast(1)), Cd(Scanner.history(s, "240", 1).dropLast(1)))
                            status = "Загружено ${done.incrementAndGet()} из ${syms.size}"; Store.ver++; d
                        } catch (e: Exception) { done.incrementAndGet(); null }
                    }
                })
                ex.shutdown()
                val ds = fs.mapNotNull { it.get() }
                if (ds.isEmpty()) throw Exception("нет данных, проверь интернет")
                status = "Считаю…"; Store.ver++
                val off = cfg.copy(adxMin = 0.0, btcOn = false, htfOn = false, minVr = 0.0, minStop = 0.1, maxStop = 100.0)
                val variants = listOf(
                    "Базовые правила (без фильтров)" to off,
                    "+ фильтр BTC" to off.copy(btcOn = true),
                    "+ тренд 4Ч" to off.copy(htfOn = true),
                    "+ ADX" to off.copy(adxMin = if (cfg.adxMin > 0) cfg.adxMin else 20.0),
                    "+ объём ×1.5 и выше" to off.copy(minVr = 1.5),
                    "Мои настройки (все фильтры)" to cfg,
                    "Мои настройки без управления сделкой" to cfg.copy(partial = 0.0, beOn = false, trail = false)
                )
                results = variants.map { (name, cf) -> stats(name, sim(ds, btc, cf)) }
                status = "Готово: ${ds.size} монет, ~${bx.n / 24} дней истории"
            } catch (e: Throwable) { status = "Ошибка: ${e.message}" }
            finally { running = false; Store.ver++ }
        }
    }

    private fun sim(ds: List<BData>, btc: Map<Long, Int>, cf: Cfg): List<Tr> {
        val out = ArrayList<Tr>(); val H4 = 14_400_000L
        for (d in ds) {
            val x = d.x; if (x.n < 260) continue
            var busy = -1; var i = 210
            while (i < x.n - 1) {
                if (i > busy) {
                    val cs = Scanner.closedSignal(x, d.e5, d.e2, d.ad, i, cf, x.c[i])
                    if (cs != null) {
                        val L = cs.long; var ok = true
                        if (cf.btcOn && (btc[x.t[i]] ?: 0) == (if (L) -1 else 1)) ok = false
                        if (ok && cf.htfOn) {
                            val s4 = x.t[i] / H4 * H4
                            val k = if (x.t[i] + 3_600_000L == s4 + H4) d.idx4[s4] else d.idx4[s4 - H4]
                            ok = k != null && k >= 205 && Scanner.dirSimple(d.f5, d.f2, k) == (if (L) 1 else -1)
                        }
                        val e = x.c[i]; val dd = abs(e - cs.ext) + e * 0.001; val sp = dd / e * 100
                        if (ok && sp >= cf.minStop && sp <= cf.maxStop) {
                            val r = trade(x, d.e5, i, L, e, dd, cf)
                            if (r != null) { out.add(Tr(x.t[i], r.first)); busy = r.second }
                        }
                    }
                }
                i++
            }
        }
        return out
    }

    // Возвращает (результат в R, индекс свечи выхода). Сделки без выхода к концу истории не считаем.
    private fun trade(x: Cd, e5: DoubleArray, i: Int, L: Boolean, e: Double, d: Double, cf: Cfg): Pair<Double, Int>? {
        val qty = 1.0 / d
        val p = Pos("", L, e, if (L) e - d else e + d, if (L) e + d * cf.rr else e - d * cf.rr, qty, x.t[i], x.t[i], e, d, 0.0)
        for (j in i + 1 until x.n) {
            var ex = Demo.step(p, x.h[j], x.l[j], x.t[j], cf)
            if (ex == null && p.stage == 1 && cf.trail && x.t[j] > p.stageAt && (if (L) x.c[j] < e5[j] else x.c[j] > e5[j])) ex = Pair(x.c[j], "EMA")
            if (ex == null && j - i >= 72) ex = Pair(x.c[j], "Время")
            if (ex != null) return Pair(p.realized + Demo.pnl(L, e, ex.first, qty * p.rem), j)
        }
        return null
    }

    private fun stats(name: String, t: List<Tr>): Res {
        val s = t.sortedBy { it.t }; val n = s.size
        if (n == 0) return Res(name, 0, 0.0, 0.0, 0.0, 0.0, 0.0)
        var cum = 0.0; var peak = 0.0; var dd = 0.0; var pos = 0.0; var neg = 0.0; var w = 0
        for (x in s) { cum += x.r; if (cum > peak) peak = cum; dd = maxOf(dd, peak - cum); if (x.r > 0) { pos += x.r; w++ } else neg += x.r }
        return Res(name, n, w * 100.0 / n, cum / n, cum, if (neg < 0) pos / -neg else 99.0, dd)
    }
}
