plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.scanner.bybit"
    compileSdk = 34
    defaultConfig { applicationId = "com.scanner.bybit"; minSdk = 26; targetSdk = 34; versionCode = 3; versionName = "2.1" }
    // Фиксированный ключ: новые версии ставятся поверх старых, демо-данные сохраняются
    val ks = file("debug.keystore")
    if (ks.exists()) {
        signingConfigs.getByName("debug") { storeFile = ks; storePassword = "android"; keyAlias = "androiddebugkey"; keyPassword = "android" }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
